<?php

$PERMISSION = ['admin', 'master', 'moderator', 'support'];
$CURRENT_PAGE = 'index';
$PAGE_TITLE = 'Yönetim Sayfası';

include './assets/php/connection.php';
include './assets/php/bwpv_database.php';
include './assets/php/function.php';
include './assets/php/header.php';

?>

<!doctype html>
<html class="no-js h-100" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $PAGE_TITLE; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php 
    $CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $PERMISSION);
    if($CHECK_PERMISSION == 0){
        include './assets/php/footer.php'; 
        die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_PERMISSION, "Tamam", 0, 0, 0));
    }
?>

<?php

$query_vusca_banlist = $bwpv_pdo->query("SELECT * FROM vusca_banlist", PDO::FETCH_ASSOC);
$count_vusca_banlist = $query_vusca_banlist->rowCount();

$query_reality_banlist = $bwpv_pdo->query("SELECT * FROM reality_banlist", PDO::FETCH_ASSOC);
$count_reality_banlist = $query_reality_banlist->rowCount();

$query_communityservice = $bwpv_pdo->query("SELECT * FROM communityservice", PDO::FETCH_ASSOC);
$count_communityservice = $query_communityservice->rowCount();

$query_jail = $bwpv_pdo->query("SELECT * FROM jail", PDO::FETCH_ASSOC);
$count_jail = $query_jail->rowCount();

$query_users = $bwpv_pdo->query("SELECT * FROM users", PDO::FETCH_ASSOC);
$count_users = $query_users->rowCount();

?>
<!-- Header End -->
<div class="main-content-container container-fluid px-4">
    <!-- Page Header -->
    <button type="button" class="btn mt-4 mb-4 text-white font-weight-bold" style="background-color: #FF6100"><?php echo $PAGE_TITLE; ?></button>

    <!-- Small Stats Blocks -->
    <div class="row">
        <div class="col-lg col-md-4 col-sm-6 mb-4">
            <div class="stats-small stats-small--1 card card-small">
                <div class="card-body p-0 d-flex">
                    <div class="d-flex flex-column m-auto">
                        <div class="stats-small__data text-center"> <span class="stats-small__label">(Your Server Name) Tarafından Yasaklanmış<br>Oyuncu Sayısı</span>
                            <h6 class="stats-small__value count my-3"> <?php echo $count_vusca_banlist; ?> </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg col-md-6 col-sm-6 mb-4">
            <div class="stats-small stats-small--1 card card-small">
                <div class="card-body p-0 d-flex">
                    <div class="d-flex flex-column m-auto">
                        <div class="stats-small__data text-center"> <span class="stats-small__label">CVGRI Anti Cheat Tarafından Yasaklanmış<br>Oyuncu Sayısı</span>
                            <h6 class="stats-small__value count my-3"> <?php echo $count_reality_banlist; ?> </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg col-md-6 col-sm-6 mb-4">
            <div class="stats-small stats-small--1 card card-small">
                <div class="card-body p-0 d-flex">
                    <div class="d-flex flex-column m-auto">
                        <div class="stats-small__data text-center"> <span class="stats-small__label">Kamu Hizmeti Olan<br>Oyuncu Sayısı</span>
                            <h6 class="stats-small__value count my-3"> <?php echo $count_communityservice; ?> </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg col-md-6 col-sm-6 mb-4">
            <div class="stats-small stats-small--1 card card-small">
                <div class="card-body p-0 d-flex">
                    <div class="d-flex flex-column m-auto">
                        <div class="stats-small__data text-center"> <span class="stats-small__label">Hapishanede Olan<br>Oyuncu Sayısı</span>
                            <h6 class="stats-small__value count my-3"> <?php echo $count_jail; ?> </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg col-md-6 col-sm-6 mb-4">
            <div class="stats-small stats-small--1 card card-small">
                <div class="card-body p-0 d-flex">
                    <div class="d-flex flex-column m-auto">
                        <div class="stats-small__data text-center"> <span class="stats-small__label">Kayıtlı<br>Oyuncu Sayısı</span>
                            <h6 class="stats-small__value count my-3"> <?php echo $count_users; ?> </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

        <div class="row">


        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="card card-small h-90">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Oyuncu Yasaklama Menüsü</h6>
                </div>
                <div class="card-body d-flex flex-column">
                    <form method="post">
                        <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="steam" id="steam" class="form-control" value="steam:" placeholder="steam:">
                                </div>
                                <div class="form-group">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="rockstar" name="id" class="form-control" value="license:" placeholder="license:">
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="xbox" id="xbox" class="form-control" value="xbl:" placeholder="xbl:">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="live" id="live" class="form-control" value="live:" placeholder="live:">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="discord" id="discord" class="form-control" value="discord:" placeholder="discord:">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="ip" id="ip" class="form-control" value="ip:" placeholder="ip:">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="reason" id="reason" class="form-control" placeholder="Yasaklanma Nedeni" require>
                                        </div>
                                    </div>
                                    <div class="form-group"> 
                                      <select id="inputState" name="time" id="time" class="form-control">
                                            <option value="252460800" class="text-danger" selected>Kalıcı Yasaklama</option>
                                            <option value="3600" class="text-primary">1 Saat</option>
                                            <option value="7200" class="text-primary">2 Saat</option>
                                            <option value="10800" class="text-primary">3 Saat</option>
                                            <option value="86400" class="text-primary">1 Gün</option>
                                            <option value="172800" class="text-primary">2 Gün</option>
                                            <option value="259200" class="text-primary">3 Gün</option>
                                            <option value="604800" class="text-primary">1 Hafta</option>
                                            <option value="1209600" class="text-primary">2 Hafta</option>
                                            <option value="2629800" class="text-primary">1 Ay</option>
                                        </select> 
                                    </div>
                                </div>
                            </div> <button type="submit" name="button_ban_player" class="btn btn-danger">Oyuncuyu Yasakla</button>
                        </div> <input type="hidden" name="csrf_ban_player" value="<?php echo GENERATE_CSRF_TOKEN();?>">
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="card card-small h-90">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Oyuncunun Tüm Verilerini Sil</h6>
                </div>
                <div class="card-body d-flex flex-column">
                    <form method="post">
                        <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="steam_delete_player" id="steam_delete_player" class="form-control" value="steam:">
                                </div>
                            </div> <button type="submit" name="button_delete_player" class="btn btn-warning text-white">Oyuncunun Verilerini Sil</button>
                        </div> <input type="hidden" name="csrf_delete_player" value="<?php echo GENERATE_CSRF_TOKEN();?>">
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <div class="card card-small h-90">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Oyuncunun Tüm Yasağını Kaldır</h6>
                </div>
                <div class="card-body d-flex flex-column">
                    <form method="post">
                        <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="material-icons">subject</i></span></div> <input type="text" name="steam_remove_ban" id="steam_remove_ban" class="form-control" value="steam:">
                                </div>
                            </div> <button type="submit" name="button_remove_ban" class="btn btn-success">Oyuncunun Yasağını Kaldır</button>
                        </div> <input type="hidden" name="csrf_remove_ban" value="<?php echo GENERATE_CSRF_TOKEN();?>">
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>


<?php 
include './assets/php/footer.php'; 
?>

</body>
</html>

<script>
function copyToClipboard(text) {
    var dummy = document.createElement("textarea");
    document.body.appendChild(dummy);
    dummy.value = text;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
}
</script>

<script>
function copyButton(text) {
    copyToClipboard(text);
    Swal.fire({
        position: 'top-end',
        icon: 'success',
        color: '#fff',
        background: '#191815',
        title: 'Panoya Kopyalandı',
        showConfirmButton: false,
        timer: 600
    });
}
</script>

<script>
$('.DELETE').on('click', function(){
  const ID = $(this).data('id')
  const DATABASE = 'notification_site'
  const data = {
    ID: ID,
    DATABASE: DATABASE,
    ACTION: 'DELETE',
    CSRF_TOKEN: '<?php echo GENERATE_CSRF_TOKEN(); ?>',
    SESSION_USERNAME : '<?php echo $SESSION_USERNAME; ?>',
    SESSION_PERMISSION : '<?php echo $SESSION_PERMISSION; ?>'
  }
  $.post('./assets/php/ajax.php', data, function(response) {
    if (response.error) {
        Swal.fire({icon: 'error',title: 'Başarısız',confirmButtonText: 'Tamam',text: response.error,footer: '<a href="index.php"><?php echo "<center>Tarih : $CURRENT_DATE_AND_TIME<br>IP : $IP_ADDRESS</center>"; ?></a>'}).then(function() { window.location = 'index.php'});
    } else {
        Swal.fire({icon: 'success',title: 'Başarılı',confirmButtonText: 'Tamam',text: 'Bildirim başarıyla tüm kullanıcılardan silindi.',footer: '<a href="index.php"><?php echo "<center>Tarih : $CURRENT_DATE_AND_TIME<br>IP : $IP_ADDRESS</center>"; ?></a>'}).then(function() { window.location = 'index.php'});
    }
  }, 'json')
});
</script>


<?php

if(isset($_POST['button_ban_player'])){

    $POST_PERMISSION = ['admin', 'moderator', 'master'];
    $CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $POST_PERMISSION);
    if($CHECK_PERMISSION == 0){
        die(SWEET_ALERT("error", "Erişim Engellendi", "Bu sistemi kullanmaya yetkiniz bulunmuyor. Eğer yetki almak istiyorsanız lütfen sistem yöneticisi ile iletişime geçin.", "Tamam", 0, 0, "index.php"));
    }

    $POST_CSRF_TOKEN = htmlspecialchars($_POST['csrf_ban_player']);
    $name = $UNIX_DATE;
    $admin = $SESSION_USERNAME;
    $steam = htmlspecialchars($_POST['steam']);
    $rockstar = htmlspecialchars($_POST['rockstar']);
    $xbox = htmlspecialchars($_POST['xbox']);
    $live = htmlspecialchars($_POST['live']);
    $discord = htmlspecialchars($_POST['discord']);
    $ip = htmlspecialchars($_POST['ip']);
    $reason = htmlspecialchars($_POST['reason']);
    $time = htmlspecialchars($_POST['time']);
    $time = $UNIX_DATE + $time;
    $CSRF_CHECK = DECRYPT($POST_CSRF_TOKEN);

    if(empty($steam) OR empty($rockstar) OR empty($xbox) OR empty($live) OR empty($discord) OR empty($ip) OR empty($reason)){
        die(SWEET_ALERT("error", "Erişim Engellendi", "Lütfen tüm alanları eksiksiz bir şekilde doldurun.", "Tamam", 0, 0, "index.php"));
    }

    $query_vusca_banlist = $bwpv_pdo->prepare("INSERT INTO vusca_banlist SET name = ?, admin = ?, steam = ?, rockstar = ?, xbox = ?, live = ?, discord = ?, ip = ?, reason = ?, time = ?"); 
    $insert_vusca_banlist = $query_vusca_banlist->execute(array($name, $admin, $steam, $rockstar, $xbox, $live, $discord, $ip, $reason, $time));
    $LOG_USER_REQUEST = LOG_USER_REQUEST($SESSION_USERNAME, "Bir oyuncuyu sunucudan yasakladı. [ steam:$steam, rockstar:$rockstar, xbox:$xbox, live:$live, discord:$discord, ip:$ip, reason:$reason ]");
    
    if($insert_vusca_banlist){
       echo SWEET_ALERT("success", "Başarılı", "Oyuncu başarıyla yasaklandı. Sunucuya girişi tamamen engellendi. Oyuncu eğer halen sunucudaysa sunucudan atmayı unutma.", "Tamam", 0, 0, "index.php");
       die();
    }
    else{
        echo SWEET_ALERT("error", "Başarısız", "Oyuncu yasaklanırken sistemsel bir problem oluştu, lütfen tekrar deneyin veya yazılım ekibi ile iletişime geçin.", "Tamam", 0, 0, "index.php");
        die();
    }

}

if(isset($_POST['button_delete_player'])){

  $POST_PERMISSION = ['admin', 'master'];
  $CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $POST_PERMISSION);
  if($CHECK_PERMISSION == 0){
      die(SWEET_ALERT("error", "Erişim Engellendi", "Bu sistemi kullanmaya yetkiniz bulunmuyor. Eğer yetki almak istiyorsanız lütfen sistem yöneticisi ile iletişime geçin.", "Tamam", 0, 0, "index.php"));
  }

  $admin = $SESSION_USERNAME;
  $steam = htmlspecialchars($_POST['steam_delete_player']);

  if(empty($admin) OR empty($steam)){
      die(SWEET_ALERT("error", "Erişim Engellendi", "Lütfen tüm alanları eksiksiz bir şekilde doldurun.", "Tamam", 0, 0, "index.php"));
  }

  $data = ["$steam"];
  $data2 = "Motel$steam";
  $data2 = ["$data2"];
  $count_delete = 0;

  $sql = "DELETE FROM users WHERE identifier=?";
  $statement = $bwpv_pdo->prepare($sql);
  if($statement->execute($data)) {
    $count_delete = $count_delete + 1;
  }

  $sql = "DELETE FROM playerskins WHERE citizenid=?";
  $statement = $bwpv_pdo->prepare($sql);
  if($statement->execute($data)) {
    $count_delete = $count_delete + 1;
  }

  $sql = "DELETE FROM player_outfits WHERE citizenid=?";
  $statement = $bwpv_pdo->prepare($sql);
  if($statement->execute($data)) {
    $count_delete = $count_delete + 1;
  }

  $sql = "DELETE FROM owned_vehicles WHERE owner=?";
  $statement = $bwpv_pdo->prepare($sql);
  if($statement->execute($data)) {
    $count_delete = $count_delete + 1;
  }

  $sql = "DELETE FROM vusca_inv_stash WHERE stash=?";
  $statement = $bwpv_pdo->prepare($sql);
  $statement->execute($data2);

  $sql = "DELETE FROM user_licenses WHERE owner=?";
  $statement = $bwpv_pdo->prepare($sql);
  if($statement->execute($data)) {
    $count_delete = $count_delete + 1;
  }

  $sql = "DELETE FROM datastore_data WHERE owner=?";
  $statement = $bwpv_pdo->prepare($sql);
  if($statement->execute($data)) {
    $count_delete = $count_delete + 1;
  }

  $sql = "DELETE FROM characters WHERE identifier=?";
  $statement = $bwpv_pdo->prepare($sql);
  if($statement->execute($data)) {
    $count_delete = $count_delete + 1;
  }

  if($count_delete > 1){
     echo SWEET_ALERT("success", "Başarılı", "Oyuncunun verileri başarıyla silindi. Veri tabanlarından silnen toplam veri sayısı ( $count_delete )", "Tamam", 0, 0, "index.php");
     die();
  }
  else{
      echo SWEET_ALERT("error", "Başarısız", "Oyuncunun verileri silinirken sistemsel bir problem oluştu, lütfen tekrar deneyin veya yazılım ekibi ile iletişime geçin.", "Tamam", 0, 0, "index.php");
      die();
  }

}

if(isset($_POST['button_remove_ban'])){

    $POST_PERMISSION = ['admin', 'master'];
    $CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $POST_PERMISSION);
    if($CHECK_PERMISSION == 0){
        die(SWEET_ALERT("error", "Erişim Engellendi", "Bu sistemi kullanmaya yetkiniz bulunmuyor. Eğer yetki almak istiyorsanız lütfen sistem yöneticisi ile iletişime geçin.", "Tamam", 0, 0, "index.php"));
    }
  
    $admin = $SESSION_USERNAME;
    $steam = htmlspecialchars($_POST['steam_remove_ban']);
    $message = "";
    $count = 0;
    $data = ["$steam"];
    $data2 = "Motel$steam";
    $data2 = ["$data2"];
  
    if(empty($admin) OR empty($steam)){
        die(SWEET_ALERT("error", "Erişim Engellendi", "Lütfen tüm alanları eksiksiz bir şekilde doldurun.", "Tamam", 0, 0, "index.php"));
    }
  
    $sql = "DELETE FROM vusca_banlist WHERE steam=?";
    $statement = $bwpv_pdo->prepare($sql);
    if($statement->execute($data)) {
        $count = $count + 1;
    }

    $sql = "DELETE FROM reality_banlist WHERE steam=?";
    $statement = $bwpv_pdo->prepare($sql);
    if($statement->execute($data)) {
        $count = $count + 1;
    }

    if($count > 1){
       echo SWEET_ALERT("success", "$steam", "Tüm veri tabanlarından oyuncunun yasağı kaldırıldı.", "Tamam", 0, 0, "index.php");
       die();
    }
    else{
        echo SWEET_ALERT("error", "Başarısız", "Oyuncunun yasağı kaldırılırken sistemsel bir problem oluştu, oyuncu hiçbir yasak listesinde olmayabilir. Lütfen tekrar deneyin veya yazılım ekibi ile iletişime geçin.", "Tamam", 0, 0, "index.php");
        die();
    }
  
  }

?>