<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./assets/images/favicon.png">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="icon" href="./assets/images/favicon.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="./assets/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="./assets/styles/extras.1.1.0.min.css">
    <title>Çıkış Yap</title>
<style>
body {
  background-color: #BD11DC;
}
</style>
</head>
<body>
    
</body>
</html>

<?php

include './assets/php/function.php';
include './assets/php/connection.php';

session_start();

if(isset($_SESSION['USERNAME'])){
  $SESSION_USERNAME = $_SESSION['USERNAME'];
  $SESSION_DISCORD = $_SESSION['DISCORD'];
  LOG_USER_REQUEST($SESSION_USERNAME, "Hesabından çıkış yaptı.");
}

session_destroy();

echo "<script>
Swal.fire({
  icon: 'success',
  title: 'Çıkış Yaptınız',
  color: '#fff',
  background: '#191815',
  text: 'Güvenli bir şekilde sistemden çıkış yaptınız, giriş sayfasına yönlendiriliyorsunuz.',
  confirmButtonText: 'Tamam'
  }).then(function() { window.location = 'login.php'});
</script>";

header("refresh:3;url=login.php");
?>