<?php

$PERMISSION = ['admin'];
$CURRENT_PAGE = 'database';
$FILE_NAME = $CURRENT_PAGE.'.php';
$PAGE_TITLE = 'Veri Tabanı';

include './assets/php/connection.php';
include './assets/php/function.php';
include './assets/php/header.php';

if(!empty($_GET['DATABASE'])){
  $SELECTED_QUERY = $_GET['DATABASE'];
}
else{
  header("refresh:0;url=$FILE_NAME?DATABASE=users&PAGE=1");
}

$GET_COLUMN_NAMES = $conn->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DATABASE_NAME' AND TABLE_NAME = '$SELECTED_QUERY'");
while($ROW = $GET_COLUMN_NAMES->fetch_assoc()){
    $ARRAY_COLUMN_NAMES[] = $ROW;
}
$COUNT_COLUMN_NAMES = count($ARRAY_COLUMN_NAMES);
$COUNT_COLUMN_NAMES = $COUNT_COLUMN_NAMES-1;

$GET_TABLE_NAMES = $conn->query("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '$DATABASE_NAME' ORDER BY TABLE_NAME");
while($TABLES = $GET_TABLE_NAMES->fetch_assoc()){
    $ARRAY_TABLE_NAMES[] = $TABLES;
}
$COUNT_TABLE_NAMES = count($ARRAY_TABLE_NAMES);
$COUNT_TABLE_NAMES = $COUNT_TABLE_NAMES-1;

?>

<!doctype html>
<html class="no-js h-100" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $PAGE_TITLE; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php 
    $CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $PERMISSION);
    if($CHECK_PERMISSION == 0){
        include './assets/php/footer.php'; 
        die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_PERMISSION, "Tamam", 0, 0, 0));
    }
?>

<div class="main-content-container container-fluid px-4">
<!-- Page Header -->
<button type="button" class="btn btn-danger mt-4 mb-4 text-white font-weight-bold DELETE_ALL">Hepsini Sil</button>
<button type="button" class="btn btn-success mt-4 mb-4 text-white font-weight-bold" data-toggle="modal" data-target="#modal_add_new_record">Yeni Kayıt Ekle</button>
<!-- End Page Header -->

<!-- StartLog Record Table -->
<div class="form-group">
<label for="SELECT_TABLE">Lütfen bir veri tabanı seçin :</label>
<select class="form-control is-valid mt-1" id="SELECT_TABLE" name="SELECT_TABLE" onchange="SELECT_TABLE()" >
<?php 
for($i = 0; $i <= $COUNT_TABLE_NAMES; $i++){
  $TABLE_NAME = $ARRAY_TABLE_NAMES[$i]['TABLE_NAME'];
  if($SELECTED_QUERY == $TABLE_NAME){
    $SELECTED_STATUS = 'selected';
  }
  else{
    $SELECTED_STATUS = "";
  }
  echo "<option value='$TABLE_NAME' $SELECTED_STATUS>$TABLE_NAME</option>";
}
?> 
</select>

<table class="table table-bordered mt-3" style="width:100%">
  <thead>
<tr>
<?php 
echo "<th><i class='material-icons'>settings</i></th>";
  for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
    $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
    echo "<th>$COLUMN_NAME</th>";
  }
?>
</tr>
</thead>
<tbody>
<?php
$COUNT_OF_SELECTED_QUERY = $DB->query("SELECT * FROM $SELECTED_QUERY", PDO::FETCH_ASSOC);
$COUNT_OF_SELECTED_QUERY = $COUNT_OF_SELECTED_QUERY->rowCount();
$PAGINATION = ceil($COUNT_OF_SELECTED_QUERY/12);
if(!empty($_GET['PAGE'])){
  $PAGE = $_GET['PAGE'];
}
if(empty($PAGE)){
  $START_COUNT = 0;
  $FINAL_COUNT = 12;
}
else{
  $START_COUNT = ($PAGE-1)*12;
  $FINAL_COUNT = $START_COUNT+12;
}
$QUERY_DATA = $DB->query("SELECT * FROM $SELECTED_QUERY ORDER BY ID DESC LIMIT $START_COUNT, $FINAL_COUNT", PDO::FETCH_ASSOC);
if($QUERY_DATA->rowCount()){
  foreach( $QUERY_DATA as $DATA ){
    echo "<tr>";
    $DATA_ID = $DATA['ID'];
    echo "<td><button data-id='$DATA_ID' class='btn btn-danger DELETE' type='button'>Delete</button><br><button data-id='$DATA_ID' class='btn btn-success mt-2 EDIT' type='button'>Edit</button></td>";
    for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
      $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
      if($COLUMN_NAME == "DATE" OR $COLUMN_NAME == "LAST_UPDATE"){
        $COLUMN_VALUE = EPOCH_CONVERTER($DATA[$COLUMN_NAME]);
      }
      else{
        $COLUMN_VALUE = $DATA[$COLUMN_NAME];
      }
      if(strlen($COLUMN_VALUE) > 40){
        if(strlen($COLUMN_VALUE) > 100){
          $SHORTENED_VALUE = mb_substr($COLUMN_VALUE, 0, 100);
          echo "<td>$SHORTENED_VALUE <div class='text-danger'>( Kısaltıldı )</div>
          <span onclick='copyOnclick(`$COLUMN_VALUE`)'><i class='material-icons text-primary'>content_copy</i></span>
          </td>";
        }
        else{
          $SPLIT_VALUE = str_split($COLUMN_VALUE, 40);
          $COUNT_SPLIT_VALUE = count($SPLIT_VALUE);
          if($COUNT_SPLIT_VALUE != 1){
            $COUNT_SPLIT_VALUE = $COUNT_SPLIT_VALUE-1;
          }
          echo "<td>";
          for($count_split = 0; $count_split <= $COUNT_SPLIT_VALUE; $count_split++){
            echo $SPLIT_VALUE[$count_split]."<br>";
          }
          echo "<span onclick='copyOnclick(`$COLUMN_VALUE`)'><i class='material-icons text-primary'>content_copy</i></span>";
          if($COLUMN_NAME == 'USER_AGENT'){
            echo "<span onclick='ADD_TO_BLACKLIST(`blacklist_useragent`, `$COLUMN_VALUE`)'><i class='material-icons text-primary'>cancel</i></span>";
          }
        }
      }
      else{
        if($COLUMN_NAME == "IP_ADDRESS"){
          echo "<td>$COLUMN_VALUE<br>
          <span onclick='copyOnclick(`$COLUMN_VALUE`)'><i class='material-icons text-primary'>content_copy</i></span>
          <span onclick='CHECK_IP_ADDRESS(`$COLUMN_VALUE`)'><i class='material-icons text-primary'>wifi_find</i></span>
          <span onclick='ADD_TO_BLACKLIST(`blacklist_ip`, `$COLUMN_VALUE`)'><i class='material-icons text-primary'>cancel</i></span>
          </td>";
        }
        elseif($COLUMN_NAME == "ISP"){
          echo "<td>$COLUMN_VALUE<br>
          <span onclick='copyOnclick(`$COLUMN_VALUE`)'><i class='material-icons text-primary'>content_copy</i></span>
          <span onclick='ADD_TO_BLACKLIST(`blacklist_isp`, `$COLUMN_VALUE`)'><i class='material-icons text-primary'>cancel</i></span>
          </td>";
        }
        elseif($COLUMN_NAME == "PASSWORD" AND $SELECTED_QUERY == "users"){
          $DECRYPTED_COLUMN_VALUE = DECRYPT($COLUMN_VALUE);
          echo "<td>$DECRYPTED_COLUMN_VALUE<br>
          <span onclick='copyOnclick(`$DECRYPTED_COLUMN_VALUE`)'><i class='material-icons text-primary'>content_copy</i></span>
          <span onclick='copyOnclick(`$COLUMN_VALUE`)'><i class='material-icons text-primary'>lock</i></span></td>";
        }
        else{
          echo "<td>$COLUMN_VALUE&nbsp;<span onclick='copyOnclick(`$COLUMN_VALUE`)'><i class='material-icons text-primary'>content_copy</i></td>";
        }
      }
    }
    echo "</tr>";
  }
}
?>
        </tbody>
    </table>

    
    <nav aria-label="Page navigation example" class="mt-4">
    <ul class="pagination mb-0">
    <a class="page-link" href="<?php 
      if(empty($_GET['PAGE']) OR $_GET['PAGE'] == 1){
        $PREVIOUS_PAGE = 1;
        $NEXT_PAGE = 2;
      }
      else{
        $PREVIOUS_PAGE = $_GET['PAGE']-1;
        $NEXT_PAGE = $_GET['PAGE']+1;
      }
      echo "$FILE_NAME?DATABASE=$SELECTED_QUERY&PAGE=$PREVIOUS_PAGE";?>">Önceki</a></li>
    
    <?php for ($count = 1; $count <= $PAGINATION; $count++): ?>
      <?php 
        if($_GET['PAGE'] == $count){
          $ACTIVE_STATUS = "active"; 
        }
        else{
          $ACTIVE_STATUS = ""; 
        }
      ?>
       <li class="page-item <?= $ACTIVE_STATUS ?>">
            <a class="page-link" href="<?=$FILE_NAME.'?DATABASE='.$SELECTED_QUERY.'&PAGE='.$count?>"><?=$count?></a>
        </li>
    <?php endfor; ?>
    
      <?php
      if($PAGINATION != $_GET['PAGE']){
        echo "<li class='page-item'><a class='page-link' href='$FILE_NAME?DATABASE=$SELECTED_QUERY&PAGE=$NEXT_PAGE'>Sonraki</a></li>";
      }
      ?>
    </ul>
</nav>
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="modal_edit" tabindex="-1" role="dialog" aria-labelledby="modal_edit" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Düzenle</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method='POST' id='form_edit_modal' name='form_edit_modal'>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="submit" id='button_edit_modal' name='button_edit_modal' class="button_edit_modal btn btn-primary">Değişiklikleri Kaydet</button>
    </form>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modal_add_new_record" tabindex="-1" role="dialog" aria-labelledby="modal_add_new_record" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Yeni Kayıt Ekle</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST">
            <?php 
              for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
                $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
                if($COLUMN_NAME != "ID" AND $COLUMN_NAME != "DATE" AND $COLUMN_NAME != "ADMIN"){
                  if($SELECTED_QUERY != 'whitelist_ip' AND $SELECTED_QUERY != 'blacklist_ip' AND $COLUMN_NAME == "IP_ADDRESS"){
                  }
                  else{
                    echo "<div class='mb-3'><label for='$COLUMN_NAME' class='form-label'>$COLUMN_NAME</label><input type='text' class='form-control' id='$COLUMN_NAME' name='$COLUMN_NAME'></div>";
                  }
                }
              }
            ?>
      </div>
      <div class="modal-footer">
      <button type="submit" id='BUTTON_ADD_NEW_RECORD' name='BUTTON_ADD_NEW_RECORD' class="btn btn-primary">Ekle</button>
            </form>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kapat</button>
      </div>
    </div>
  </div>
</div>

<?php

if(isset($_POST['BUTTON_ADD_NEW_RECORD'])){
  $SQL = "INSERT INTO $SELECTED_QUERY SET";
  $ARRAY = array();
  for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
    $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
    if($COLUMN_NAME != "ID"){
      if(!empty($_POST["$COLUMN_NAME"]) OR $COLUMN_NAME == 'DATE' OR $COLUMN_NAME == 'IP_ADDRESS' OR $COLUMN_NAME == 'ADMIN'){
        $POST_VALUE = htmlspecialchars($_POST["$COLUMN_NAME"]);
        if($SELECTED_QUERY != "blacklist_ip" AND $SELECTED_QUERY != "whitelist_ip" AND $COLUMN_NAME == 'IP_ADDRESS'){
          $POST_VALUE = $IP_ADDRESS;
        }
        if($COLUMN_NAME == 'DATE'){
          $POST_VALUE = $UNIX_DATE;
        }
        if($COLUMN_NAME == 'ADMIN'){
          $POST_VALUE = $SESSION_USERNAME;
        }
        array_push($ARRAY, $POST_VALUE);
        $SQL = $SQL." $COLUMN_NAME = ?,";
      }
      else{
        die(SWEET_ALERT('error', 'Erişim Engellendi', $DIE_POST_DATA, 0, 0, 0, "$PAGE_NAME"));
      }
    }
  }
  $SQL = substr($SQL,0,-1);
  $INSERT = $DB->prepare($SQL);
  $INSERT = $INSERT->execute($ARRAY);
  $EPOCH_DATE = EPOCH_CONVERTER($UNIX_DATE);
  $CURRENT_PAGE = $_GET['PAGE'];
  if($INSERT){
    echo SWEET_ALERT('success', 'Başarılı', "Eklemek istediğiniz kayıt başarıyla $SELECTED_DATABASE veri tabanına eklendi.", 0, "<center>IP Address : $IP_ADDRESS<br>Date : $EPOCH_DATE</center>", 0, "$PAGE_NAME?DATABASE=$SELECTED_QUERY&PAGE=$CURRENT_PAGE");
  }
  else{
    echo SWEET_ALERT('error', 'Başarısız', "Bir hata nedeniyle yeni kayıt oluşturulamadı, lütfen tekrar deneyin.", 0, "<center>IP Address : $IP_ADDRESS<br>Date : $EPOCH_DATE</center>", 0, "$PAGE_NAME?DATABASE=$SELECTED_QUERY&PAGE=$CURRENT_PAGE");
  }
}

if(isset($_POST['button_edit_modal'])){
  $SQL = "UPDATE $SELECTED_QUERY SET";
  $ARRAY = array();

  for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
    $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
    if($SESSION_PERMISSION == 'admin' OR $COLUMN_NAME != 'ID' AND $COLUMN_NAME != 'ADMIN' AND $COLUMN_NAME != 'DATE'){
      $POST_VALUE = htmlspecialchars($_POST["$COLUMN_NAME"]);
      $SQL .= " $COLUMN_NAME = ?,";
      array_push($ARRAY, $POST_VALUE);
    }
  }

  $SQL = substr($SQL,0,-1);
  $SQL .= " WHERE ID = ?";
  $ID = $_POST['ID'];
  array_push($ARRAY, $ID);

  $UPDATE = $DB->prepare($SQL)->execute($ARRAY);
  $EPOCH_DATE = EPOCH_CONVERTER($UNIX_DATE);
  $CURRENT_PAGE = $_GET['PAGE'];

  if($UPDATE){
    echo SWEET_ALERT('success', 'Başarılı', "Değiştirilmek istenen veriler başarıyla güncellendi.", 0, "<center>IP Address : $IP_ADDRESS<br>Date : $EPOCH_DATE</center>", 0, "$PAGE_NAME?DATABASE=$SELECTED_QUERY&PAGE=$CURRENT_PAGE");
  }
  else{
    echo SWEET_ALERT('error', 'Başarısız', "Değiştirlmek istenen veriler bir hata nedeniyle güncellenemedi, lütfen tekrar deneyin..", 0, "<center>IP Address : $IP_ADDRESS<br>Date : $EPOCH_DATE</center>", 0, "$PAGE_NAME?DATABASE=$SELECTED_QUERY&PAGE=$CURRENT_PAGE");
  }
}

?>

<?php include './assets/php/footer.php'; ?>
</body>
</html>

<script>

function copyToClipboard(text){
    var dummy = document.createElement("textarea");
    document.body.appendChild(dummy);
    dummy.value = text;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
}

function CHECK_IP_ADDRESS(IP_ADDRESS){
  href = "https://ip-api.com/#" + IP_ADDRESS;
  window.open(href, '_blank');
}

function ADD_TO_BLACKLIST(BLACKLIST_DATABASE, VALUE){
  Swal.fire({
  title: 'Emin misin?',
  text: VALUE + " " + BLACKLIST_DATABASE + " veri tabanına eklenecek. Onaylıyor musun?",
  icon: 'warning',
  showCancelButton: true,
  background: '#191815', 
  color: '#fff',
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Evet',
  cancelButtonText: 'Hayır'
}).then((result) => {
  if (result.isConfirmed) {
    const data = {
      DATABASE : BLACKLIST_DATABASE,
      ACTION: 'ADD_TO_BLACKLIST',
      VALUE: VALUE,
      CSRF_TOKEN: '<?php echo GENERATE_CSRF_TOKEN(); ?>',
      SESSION_USERNAME : '<?php echo $SESSION_USERNAME; ?>',
      SESSION_PERMISSION : '<?php echo $SESSION_PERMISSION; ?>'
    }
    $.post('./assets/php/ajax.php', data, function(response) {
      if(response.error){
        Swal.fire({
          icon: 'error',
          title: 'Başarısız',
          background: '#191815', 
          color: '#fff',
          text: response.error,
          footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
        }).then(function() { window.location = '<?php echo $FILE_NAME; ?>?DATABASE=<?php echo $SELECTED_QUERY; ?>&PAGE=<?php echo $_GET['PAGE']; ?>'});
      }
      if(response.success){
        Swal.fire({
          icon: 'success',
          title: 'Başarılı',
          background: '#191815', 
          color: '#fff',
          text: response.success,
          footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
        }).then(function() { window.location = '<?php echo $FILE_NAME; ?>?DATABASE=<?php echo $SELECTED_QUERY; ?>&PAGE=<?php echo $_GET['PAGE']; ?>'});
      }
    }, 'json')
  }
})
}

function copyOnclick(text){
  copyToClipboard(text);
  
  const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  background: '#191815', 
  color: '#fff',
  timer: 1200,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})

Toast.fire({
  icon: 'success',
  title: 'Kopyalandı'
})
}

function SELECT_TABLE(){
  var selectBox = document.getElementById("SELECT_TABLE");
  var selectedValue = selectBox.options[selectBox.selectedIndex].value;
  if(selectedValue && selectedValue != 'NULL'){
    window.location.href = "?DATABASE=" + selectedValue + "&PAGE=1";
  }
}

$('.DELETE').on('click', function(){
  const ID = $(this).data('id')
  const data = {
    ID: ID,
    DATABASE : '<?php echo $SELECTED_QUERY; ?>',
    ACTION: 'DELETE',
    CSRF_TOKEN: '<?php echo GENERATE_CSRF_TOKEN(); ?>',
    SESSION_USERNAME : '<?php echo $SESSION_USERNAME; ?>',
    SESSION_PERMISSION : '<?php echo $SESSION_PERMISSION; ?>'
  }
  $.post('./assets/php/ajax.php', data, function(response) {
    if(response.error){
      Swal.fire({
        icon: 'error',
        title: 'Başarısız',
        background: '#191815', 
        color: '#fff',
        text: response.error,
        footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
      }).then(function() { window.location = '<?php echo $FILE_NAME; ?>?DATABASE=<?php echo $SELECTED_QUERY; ?>&PAGE=<?php echo $_GET['PAGE']; ?>'});
    }
    if(response.success){
      Swal.fire({
        icon: 'success',
        title: 'Başarılı',
        background: '#191815', 
        color: '#fff',
        text: response.success,
        footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
      }).then(function() { window.location = '<?php echo $FILE_NAME; ?>?DATABASE=<?php echo $SELECTED_QUERY; ?>&PAGE=<?php echo $_GET['PAGE']; ?>'});
    }
  }, 'json')
});

$('.DELETE_ALL').on('click', function(){
  const DATABASE = '<?php echo $SELECTED_QUERY; ?>'
  const data = {
    DATABASE: DATABASE,
    ACTION: 'DELETE_ALL',
    CSRF_TOKEN: '<?php echo GENERATE_CSRF_TOKEN(); ?>',
    SESSION_USERNAME : '<?php echo $SESSION_USERNAME; ?>',
    SESSION_PERMISSION : '<?php echo $SESSION_PERMISSION; ?>'
  }
  $.post('./assets/php/ajax.php', data, function(response) {
    if(response.error){
      Swal.fire({
        icon: 'error',
        title: 'Başarısız',
        background: '#191815', 
        color: '#fff',
        text: response.error,
        footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
      }).then(function() { window.location = '<?php echo $FILE_NAME; ?>?DATABASE=<?php echo $SELECTED_QUERY; ?>&PAGE=<?php echo $_GET['PAGE']; ?>'});
    }
    if(response.success){
      Swal.fire({
        icon: 'success',
        title: 'Başarılı',
        background: '#191815', 
        color: '#fff',
        text: response.success,
        footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
      }).then(function() { window.location = '<?php echo $FILE_NAME; ?>?DATABASE=<?php echo $SELECTED_QUERY; ?>&PAGE=<?php echo $_GET['PAGE']; ?>'});
    }
  }, 'json')
});

</script>

<script>
$('.EDIT').on('click', function(){
  const ID = $(this).data('id')
  const data = {
    ID : ID,
    DATABASE : '<?php echo $SELECTED_QUERY; ?>',
    ACTION : 'EDIT',
    CSRF_TOKEN : '<?php echo GENERATE_CSRF_TOKEN(); ?>',
    SESSION_USERNAME : '<?php echo $SESSION_USERNAME; ?>',
    SESSION_PERMISSION : '<?php echo $SESSION_PERMISSION; ?>'
  }
  $.post('./assets/php/ajax.php', data, function(response) {
    if(response.error){
      Swal.fire({
      icon: 'error',
      title: 'Unsuccessful',
      text: response.error,
      footer: '<center>IP Address : <?php echo $IP_ADDRESS; ?><br>Date : <?php echo EPOCH_CONVERTER($UNIX_DATE); ?></center>'
    }).then(function() { window.location = '<?php echo $FILE_NAME; ?>?DATABASE=<?php echo $SELECTED_QUERY; ?>&PAGE=<?php echo $_GET['PAGE']; ?>'});
    }
    if(response.success){
      $('.modal-body').html(response.success);
      $('#modal_edit').modal('show'); 
      var form = document.getElementById("form_edit_modal");
      document.getElementById("button_edit_modal").addEventListener("click", function () {
        form.submit();
      });
    }
  }, 'json')
});
</script>
 
</body>
</html>