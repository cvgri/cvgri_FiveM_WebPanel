<?php
ob_start();
header('Location : https://discord.gg/mmKCccq7Bc');
die();
$PAGE_TITLE = "Kayıt Ol";
$CURRENT_PAGE = "register.php";

include './assets/php/connection.php';
include './assets/php/function.php';

$CURRENT_PAGE = 'register.php';
$PAGE_TITLE = 'Kayıt Ol';
$CHECK_BLACKLIST = CHECK_BLACKLIST();

$IP_DETAILS = GET_IP_DETAILS($IP_ADDRESS);
$IP_QUALITY = CHECK_IP_QUALITY($IP_DETAILS);
$QUERY = $IP_DETAILS->query;
$STATUS = $IP_DETAILS->status;
$CONTINENT = $IP_DETAILS->continent;
$CONTITENT_CODE = $IP_DETAILS->continentCode;
$COUNTRY = $IP_DETAILS->country;
$COUNTRY_CODE = $IP_DETAILS->countryCode;
$REGION = $IP_DETAILS->region;
$REGION_NAME = $IP_DETAILS->regionName;
$CITY = $IP_DETAILS->city;
$ZIP = $IP_DETAILS->zip;
$LAT = $IP_DETAILS->lat;
$LON = $IP_DETAILS->lon;
$TIMEZONE = $IP_DETAILS->timezone;
$CURRENCY = $IP_DETAILS->currency;
$ISP = $IP_DETAILS->isp;
$ORG = $IP_DETAILS->org;
$AS = $IP_DETAILS->as;
$AS_NAME = $IP_DETAILS->asname;
$MOBILE = $IP_DETAILS->mobile;
$PROXY = $IP_DETAILS->proxy;
$HOSTING = $IP_DETAILS->hosting;

$CHECK_BOT_REQUEST = CHECK_BOT_REQUEST();
$CHECK_WHITELIST = CHECK_WHITELIST();
$CHECK_BLACKLIST = CHECK_BLACKLIST();

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php echo $PAGE_TITLE; ?>
    </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
    <link rel="stylesheet" type="text/css" href="assets/vendor/animate/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/vendor/css-hamburgers/hamburgers.min.css">
    <link rel="stylesheet" type="text/css" href="assets/vendor/select2/select2.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/util.css">
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="icon" href="./assets/images/favicon/favicon.ico">
    <link rel="stylesheet" href="./assets/styles/extras.1.1.0.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">    <link rel="icon" type="image/png" href="assets/images/favicon.ico" />
    <meta name="robots" content="noindex, follow">
  </head>
  <body>

  <?php
    $QUERY_LOGIN_REQUEST = $DB->query("SELECT * FROM request_login WHERE IP_ADDRESS = '{$IP_ADDRESS}'", PDO::FETCH_ASSOC);
    $COUNT_REQUEST = $QUERY_LOGIN_REQUEST->rowCount();
    if($COUNT_REQUEST >= $MAX_LOGIN_ATTEMPT){
      echo "<p><center>$DIE_LOGIN_ATTEMPT</center></p>";
      die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_LOGIN_ATTEMPT, 0, 0, 0, 0));
    }
  ?>

    <div class="limiter">
      <div class="container-login100">
        <div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">
          <form method="POST" class="login100-form validate-form">
            <span class="login100-form-title p-b-55">
            YENİ HESAP OLUŞTUR
            </span>
            <div class="wrap-input100 validate-input m-b-16">
              <input class="input100" type="text" name="INPUT_USERNAME" id="INPUT_USERNAME" placeholder="Kullanıcı Adı" minlength="3" required>
              <span class="focus-input100">
              </span>
              <span class="symbol-input100">
                <span class="lnr lnr-user">
                </span>
              </span>
            </div>
            <div class="wrap-input100 validate-input m-b-16">
              <input class="input100" type="text" name="INPUT_NAME" id="INPUT_NAME" placeholder="Adınız" minlength="2" required>
              <span class="focus-input100">
              </span>
              <span class="symbol-input100">
              <span class="lnr lnr-chevron-right-circle"></span>
                </span>
              </span>
            </div>
            <div class="wrap-input100 validate-input m-b-16">
              <input class="input100" type="text" name="INPUT_SURNAME" id="INPUT_SURNAME" placeholder="Soyadınız" minlength="2" required>
              <span class="focus-input100">
              </span>
              <span class="symbol-input100">
              <span class="lnr lnr-chevron-right-circle"></span>
                </span>
              </span>
            </div>
            <div class="wrap-input100 validate-input m-b-16">
              <input class="input100" type="password" name="INPUT_PASSWORD" id="INPUT_PASSWORD" placeholder="Şifre" minlength="6" required>
              <span class="focus-input100">
              </span>
              <span class="symbol-input100">
                <span class="lnr lnr-lock">
                </span>
              </span>
            </div>
            <div class="container-login100-form-btn p-t-25">
              <button class="login100-form-btn" id="BUTTON_REGISTER" name="BUTTON_REGISTER">
                KAYIT OL
              </button>
              </form>
              <div class ="mt-5">
                <span class="txt1">
                  Zaten hesabın var mı?
                </span>
                <a class="txt1 bo1 hov1" href="login.php">
                  Giriş Yap
                </a>
              </div>
            </div>
        </div>
      </div>
    </div>
  </body>
</html>
<script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script>

<?php
if(isset($_POST['BUTTON_REGISTER'])){

  $INPUT_USERNAME = htmlspecialchars($_POST['INPUT_USERNAME']);
  $INPUT_USERNAME = strtolower($INPUT_USERNAME);
  $INPUT_PASSWORD = htmlspecialchars($_POST['INPUT_PASSWORD']);
  $INPUT_NAME = htmlspecialchars($_POST['INPUT_NAME']);
  $INPUT_SURNAME = htmlspecialchars($_POST['INPUT_SURNAME']);
  $INPUT = "$INPUT_USERNAME - $INPUT_PASSWORD - $INPUT_NAME - $INPUT_SURNAME";

  if(!$INPUT_USERNAME OR !$INPUT_PASSWORD OR !$INPUT_NAME OR !$INPUT_SURNAME){
    $QUERY_LOGIN_REQUEST = $DB->prepare("INSERT INTO loginrequest SET ip = ?, ua = ?, country = ?, isp = ?, input = ?, date = ?");
    $INSERT_LOGIN_REQUEST = $QUERY_LOGIN_REQUEST->execute(array($IP_ADDRESS, $USER_AGENT, $COUNTRY, $ISP, $INPUT, $UNIX_DATE_AND_TIME));
    die(SWEET_ALERT("error", "Eksik Bilgi", "Lütfen kayıt işlemini tamamlamak için tüm alanları eksiksiz doldurun.", "Tamam", 0, 0, 0));
  }

  $QUERY_DATABASE = $DB->query("SELECT * FROM users", PDO::FETCH_ASSOC);
  $QUERY_DATABASE->rowCount();
      foreach($QUERY_DATABASE as $DATA){
          /* if($DATA["IP_ADDRESS"] == $IP_ADDRESS OR $DATA["USER_AGENT"] == $USER_AGENT){
            die(SWEET_ALERT("error", "Erişim Engellendi", "Daha önce bir hesap oluşturduğunuz için bir hesap daha oluşturamazsınız.", "Tamam", 0, 0, 0));
          } */
      }

  $QUERY_USERS = $DB->query("SELECT * FROM users WHERE USERNAME = '{$INPUT_USERNAME}'")->fetch(PDO::FETCH_ASSOC);

  if(!empty($QUERY_USERS)){
    $QUERY_LOGIN_REQUEST = $DB->prepare("INSERT INTO loginrequest SET ip = ?, ua = ?, country = ?, isp = ?, input = ?, date = ?");
    $INSERT_LOGIN_REQUEST = $QUERY_LOGIN_REQUEST->execute(array($IP_ADDRESS, $USER_AGENT, $COUNTRY, $ISP, $INPUT, $UNIX_DATE_AND_TIME));
    die(SWEET_ALERT("error", "Geçersiz Kullanıcı Adı", "Üzgünüz, bu kullanıcı adı daha önce alınmış lütfen başka bir kullanıcı adı seç.", "Tamam", "Zaten hesabın var mı?", 0, 0));
  }
  else{
      $PROFILE_PICTURE = "./assets/images/users/$INPUT_USERNAME.jpg";
      copy("./assets/images/default/account.png", $PROFILE_PICTURE);
      $INSERT_USERS_SQL = $DB->prepare("INSERT INTO users SET 
      IP_ADDRESS = ?, 
      USER_AGENT = ?, 
      COUNTRY = ?, 
      ISP = ?, 
      USERNAME = ?, 
      PASSWORD = ?, 
      NAME = ?, 
      SURNAME = ?, 
      PROFILE_PICTURE = ?, 
      PERMISSION = ?, 
      SUSPEND = ?, 
      DATE = ?"
      ); 
      $INSERT_USERS = $INSERT_USERS_SQL->execute(array(
      $IP_ADDRESS, 
      $USER_AGENT, 
      $COUNTRY, 
      $ISP, 
      $INPUT_USERNAME, 
      ENCRYPT($INPUT_PASSWORD), 
      $INPUT_NAME, 
      $INPUT_SURNAME, 
      $PROFILE_PICTURE, 
      'support', 
      0,
      $UNIX_DATE_AND_TIME
    ));
      if($INSERT_USERS){
        die(SWEET_ALERT("success", "Hesap Başarıyla Oluşturuldu", "Hesabınız başarıyla oluşturuldu, sizi giriş sayfasına yönlendiriyoruz artık paneli kullanabilirsiniz.", "Tamam", "Giriş Yap", "login.php", "login.php"));
      }
      else{
        die(SWEET_ALERT("error", "Hesap Oluşturulamadı", "Bilinmeyen bir hata nedeniyle hesabınızı oluşturamadık lütfen tekrar deneyin eğer işe yaramazsa lütfen sistem yöneticisi ile iletişime geçin.", "Tekrar Dene", 0, 0 , "register.php"));
      }
    }
}
?>