<?php

include 'connection.php';
include 'function.php';

$GET_DATA = $_GET["DATA"];
$ARRAY_DATA = explode('-', $GET_DATA);
$GET_PASSWORD = $ARRAY_DATA[0];
$GET_ACTION = $ARRAY_DATA[1];
$GET_CUSTOMER_ID = $ARRAY_DATA[2];

if(empty($GET_PASSWORD) OR empty($GET_ACTION) OR empty($GET_CUSTOMER_ID)){
    die("EKSİK PARAMETRE");
}

try {
    $databasename = 'dijihbtq_elitelegends';
    $databaseusername = 'dijihbtq_elitelegends';
    $databasepassword = 'VxdLmRe!hA@h';
    $db = new PDO("mysql:host=localhost;dbname=$databasename;charset=utf8", "$databaseusername", "$databasepassword");
} catch ( PDOException $e ){
    die($e->getMessage());
}

$QUERY_CUSTOMERS = $db->query("SELECT * FROM customers WHERE id = '{$GET_CUSTOMER_ID}'", PDO::FETCH_ASSOC);
if ( $QUERY_CUSTOMERS->rowCount() ){
     foreach( $QUERY_CUSTOMERS as $CUSTOMER ){
          $CUSTOMER_USERNAME = $CUSTOMER['username'];
          $CUSTOMER_PASSWORD = $CUSTOMER['password'];
          $CUSTOMER_NAME = $CUSTOMER['name'];
          $CUSTOMER_TOKEN = $CUSTOMER['token'];
          $CUSTOMER_CHATID = $CUSTOMER['chatid'];
          $CUSTOMER_REDIRECT = $CUSTOMER['redirect'];
          $CUSTOMER_REDIRECT_STATUS = $CUSTOMER['redirect_status'];
     }
}
else{
    die("VERİ TABANINA ERİŞİLEMEDİ");
}

if(empty($CUSTOMER_USERNAME) OR empty($CUSTOMER_PASSWORD)){
    die("GEÇERSİZ KULLANICI");
}

if($CUSTOMER_PASSWORD != $GET_PASSWORD){
    die("KULLANICI ŞİFRESİ YANLIŞ");
}

function MESSAGE_TELEGRAM($MESSAGE){
global $CUSTOMER_CHATID, $CUSTOMER_TOKEN, $GET_ACTION;
    $PARAMETER = array(
        'chat_id' => "$CUSTOMER_CHATID",
        'text' => "
        $MESSAGE
        ");
    $ch = curl_init();
    $url = "https://api.telegram.org/bot".$CUSTOMER_TOKEN."/sendmessage";
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $PARAMETER);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
}

$UNIX_TIME = time();

function TIME_TO_UNIX($UNIX_TIME){
    return gmdate('d/m/Y ( H:i:s )', $UNIX_TIME);
}

if($GET_ACTION = "COMPUTER_STARTED"){
    $MESSAGE = "🔔 Bilgisayar Başatıldı 🔔\nTarih : $CURRENT_DATE_AND_TIME";
}

if(!empty($MESSAGE) OR $MESSAGE == 0){
    $MESSAGE_TELEGRAM = MESSAGE_TELEGRAM($MESSAGE);
    $QUERY_LOG_CUSTOMERS = $db->prepare("INSERT INTO log_customers SET username = ?, action = ?, token = ?, chatid = ?, date = ?");
    $INSERT_LOG_CUSTOMERS = $QUERY_LOG_CUSTOMERS->execute(array("$CUSTOMER_USERNAME", "$GET_ACTION", "$CUSTOMER_TOKEN", "$CUSTOMER_CHATID", "$UNIX_TIME"));

    if($CUSTOMER_REDIRECT_STATUS == 'true' OR $CUSTOMER_REDIRECT_STATUS == '1'){
        header("Location:$CUSTOMER_REDIRECT");
    }
    else{
        die("MESAJ BAŞARIYLA TELEGRAM ARACILIĞI İLE GÖNDERİLDİ.");
    }
}
else{
    die("İŞLEM BİLGİSİ GEÇERLİ DEĞİL, MESAJ GÖNDERİLEMEDİ.");
}

?>