<?php

include 'config.php';

// Local Database Connection
try {
    $DB = new PDO("mysql:host=$DATABASE_HOST;dbname=$DATABASE_NAME;charset=utf8", $DATABASE_USERNAME, $DATABASE_PASSWORD);
} catch ( PDOException $e ){
    die($e->getMessage());
}

$conn = new mysqli($DATABASE_HOST, $DATABASE_USERNAME, $DATABASE_PASSWORD);
if($conn->connect_error){
  die("MySQL veri tabanına bağlantı kurulamadı: " . $conn->connect_error);
}

// Settings
$QUERY_SETTINGS = $DB->query("SELECT * FROM settings ORDER BY ID", PDO::FETCH_ASSOC);
if($QUERY_SETTINGS->rowCount()){
    foreach( $QUERY_SETTINGS as $ROW ){
        $SETTING_NAME = $ROW["SETTING_NAME"];
        $SETTING_VALUE = $ROW["SETTING_VALUE"];
        ${$SETTING_NAME} = $SETTING_VALUE;
    }
}

// Required Server Data
date_default_timezone_set('Europe/Istanbul');
$DECODED_CURRENT_URL = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$ENCODED_CURRENT_URL = urlencode($DECODED_CURRENT_URL);
$CURRENT_DOMAIN = $_SERVER['HTTP_HOST'];
$CURRENT_DOMAIN_HTTPS = "https://$CURRENT_DOMAIN/";
$UNIX_DATE = $_SERVER['REQUEST_TIME'];
$USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
$UNIX_DATE_AND_TIME = strtotime('now');
$CURRENT_DATE_AND_TIME = gmdate('d/m/Y ( H:i:s )', $UNIX_DATE_AND_TIME);

// Developer Mode Settings
if($DEVELOPER_MODE == 1){ 
    ini_set('display_errors', 1); 
    ini_set('display_startup_errors', 1); 
    error_reporting(E_ALL); 
} 
else{ 
    error_reporting(0); 
}

if($DEVELOPER_MODE == 1){
    $REQUESTED_PAGE = 'DEVELOPER MODE';
}
else{
    $REQUESTED_PAGE = htmlspecialchars($_SERVER['SCRIPT_URI']);
}

// Visitor Settings
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $IP_ADDRESS = htmlspecialchars($_SERVER['HTTP_CLIENT_IP']);
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $IP_ADDRESS = htmlspecialchars($_SERVER['HTTP_X_FORWARDED_FOR']);
} else {
   $IP_ADDRESS = htmlspecialchars($_SERVER['REMOTE_ADDR']);
}
if($DEVELOPER_MODE == 1){
    $IP_ADDRESS = '114.96.87.199';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=
  , initial-scale=1.0">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="icon" type="image/png" href="<?php echo "$CURRENT_DOMAIN_HTTPS"."assets/images/favicon/favicon.ico"; ?>"/>
</head>
<body>
<input type="hidden" id="IP_ADDRESS" name="IP_ADDRESS" value="<?php echo $IP_ADDRESS;?>">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>