<?php

include "config.php";

try {
    $bwpv_pdo = new PDO("mysql:host=$BWPV_DATABASE_HOST;dbname=$BWPV_DATABASE_NAME;port=3306", $BWPV_DATABASE_USERNAME, $BWPV_DATABASE_PASSWORD);
} catch ( PDOException $e ){
     print $e->getMessage();
}

$bwpv_mysql = new mysqli($BWPV_DATABASE_HOST, $BWPV_DATABASE_USERNAME, $BWPV_DATABASE_PASSWORD, $BWPV_DATABASE_NAME);
if($bwpv_mysql->connect_error){
  die("MySQL veri tabanına bağlantı kurulamadı: " . $bwpv_mysql->connect_error);
}

?>