<link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="./assets/styles/extras.1.1.0.min.css">
<link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="./assets/styles/shards-dashboards.1.1.0.min.css">
<meta name="robots" content="noindex, follow">

<?php

session_start();
$SESSION_AUTH_STATUS = $_SESSION['AUTH_STATUS'];
$SESSION_DISCORD = $_SESSION['DISCORD'];
$SESSION_USER_ID = $_SESSION['USER_ID'];
$SESSION_IP_ADDRESS = $_SESSION['IP_ADDRESS'];
$SESSION_USER_AGENT = $_SESSION['USER_AGENT'];
$SESSION_COUNTRY = $_SESSION['COUNTRY'];
$SESSION_CITY = $_SESSION['CITY'];
$SESSION_ISP = $_SESSION['ISP'];
$SESSION_USERNAME = $_SESSION['USERNAME'];
$SESSION_DISCORD = $_SESSION['DISCORD'];

if(empty($SESSION_AUTH_STATUS) OR empty($SESSION_USER_ID) OR empty($SESSION_IP_ADDRESS) OR empty($SESSION_USER_AGENT) OR empty($SESSION_COUNTRY) OR empty($SESSION_CITY) OR empty($SESSION_USERNAME)){
  session_destroy();
  header("Refresh:0; url=login.php?REDIRECT_URL=$ENCODED_CURRENT_URL");
  die();
}

/* if($SESSION_IP_ADDRESS != $IP_ADDRESS OR $SESSION_USER_AGENT != $USER_AGENT){
  session_destroy();
  echo "<p><center>$DIE_DEVICE_CHANGE</center></p>";
  die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_DEVICE_CHANGE, "Tamam", "Giriş Yap", "login.php?REDIRECT_URL=$ENCODED_CURRENT_URL", "login.php?REDIRECT_URL=$ENCODED_CURRENT_URL"));
} */

$GET_USERS_COLUMN_NAMES = $conn->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DATABASE_NAME' AND TABLE_NAME = 'users'");
while($ROW = $GET_USERS_COLUMN_NAMES->fetch_assoc()){
    $ARRAY_USERS_COLUMN_NAMES[] = $ROW;
}
$COUNT_USERS_COLUMN_NAMES = count($ARRAY_USERS_COLUMN_NAMES);
$COUNT_USERS_COLUMN_NAMES = $COUNT_USERS_COLUMN_NAMES-1;

$QUERY_USERS = $DB->prepare("SELECT * FROM users WHERE USERNAME = '{$SESSION_USERNAME}'"); 
$QUERY_USERS->execute();
$RESULT_USERS = $QUERY_USERS->fetchAll();

if(!empty($QUERY_USERS)){
  for($i = 0; $i <= $COUNT_USERS_COLUMN_NAMES; $i++){
    $COLUMN_NAME = $ARRAY_USERS_COLUMN_NAMES[$i]['COLUMN_NAME'];
    ${'SESSION_'.$COLUMN_NAME} = $RESULT_USERS['0']["$COLUMN_NAME"];
  }
}
else{
  session_destroy();
  $ERROR_MESSAGE = 'Sisteme erişebilmek için öncelikle giriş yapmalısınız.';
  echo "<p><center>$ERROR_MESSAGE</center></p>";
  die(SWEET_ALERT('error', 'Erişim Engellendi', $ERROR_MESSAGE, 'Tamam', 0, 0, "login.php?REDIRECT_URL=$ENCODED_CURRENT_URL"));
}

if($SESSION_SUSPEND == 1){
  session_destroy();
  echo '<p><center>Hesabınız yönetici tarafından devre dışı bırakılmış şu anda paneli kullanamazsınız lütfen yasağı kaldırmak için sistem yöneticisi ile iletişime geçin.</center></p>';
  die(SWEET_ALERT('error', 'Hesabınız Devre Dışı', 'Hesabınız yönetici tarafından devre dışı bırakılmış şu anda paneli kullanamazsınız lütfen yasağı kaldırmak için sistem yöneticisi ile iletişime geçin.', 'Tamam', 0, 0, 'login.php'));
}

if($SESSION_PERMISSION == 'admin'){
  $TEXT_PERMISSION = 'Yönetici';
}
elseif($SESSION_PERMISSION == 'moderator'){
  $TEXT_PERMISSION = 'Moderatör';
}
elseif($SESSION_PERMISSION == 'master'){
  $TEXT_PERMISSION = 'Master';
}
elseif($SESSION_PERMISSION == 'support'){
  $TEXT_PERMISSION = 'Destek Ekibi';
}
else{
  $TEXT_PERMISSION = 'Bilinmeyen Yetki';
}

ob_start();

$QUERY_NOTIFICATION = $DB->prepare("SELECT * FROM notification_site ORDER BY ID DESC LIMIT 8"); $QUERY_NOTIFICATION->execute(); $lastnotification = $QUERY_NOTIFICATION->fetchAll();
$COUNT_NOTIFICATION = $DB->query("SELECT * FROM notification_site", PDO::FETCH_ASSOC);
$COUNT_NOTIFICATION = $COUNT_NOTIFICATION->rowCount();

?>
<div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
      <aside id="aside_navbar" class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table my-auto ml-4">
                  <img id="main-logo" class="d-inline-block align-top" style="max-width: 25px;" src="./assets/images/favicon/favicon.png" alt="Yönetim Paneli"></img>
                  <span class="m-auto d-none d-md-inline ml-1">&nbsp;&nbsp;CVGRI Yönetim Paneli</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
              </div>
                <button type="button" class='btn btn-warning m-auto font-weight-bold text-white'><i class="material-icons">admin_panel_settings</i>Yetki : <?php echo $TEXT_PERMISSION; ?></button>
              </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link <?php echo $CURRENT_PAGE== 'index' ? 'active' : '' ?>" href="index.php">
                  <i class="material-icons">admin_panel_settings</i>
                  <span>Yönetim Sayfası</span>
                </a>
              </li>
              <li class="nav-item">
              <a class="nav-link <?php echo $CURRENT_PAGE== 'profile' ? 'active' : '' ?>" href="profile.php">
                  <i class="material-icons">manage_accounts</i>
                  <span>Profili Düzenle</span>
                </a>
              </li>
              <li class="nav-item">
              <a class="nav-link <?php echo $CURRENT_PAGE== 'logout' ? 'active' : '' ?>" href="logout.php">
                  <i class="material-icons">logout</i>
                  <span>Çıkış Yap</span>
                </a>
              </li>
              <li class="nav-item">
              <a class="nav-link <?php echo $CURRENT_PAGE== 'bannedusers' ? 'active' : '' ?>" href="bannedusers.php?PAGE=1">
                  <i class="material-icons">do_not_disturb_on</i>
                  <span>Yasakladığım Oyuncular</span>
                </a>
              </li>
              <li class="nav-item">
              <a class="nav-link <?php echo $CURRENT_PAGE== 'realitybanlist' ? 'active' : '' ?>" href="realitybanlist.php?PAGE=1">
                  <i class="material-icons">security</i>
                  <span>CVGRI Yasaklama Listesi</span>
                </a>
              </li>
              <li class="nav-item">
              <a class="nav-link <?php echo $CURRENT_PAGE== 'communityservice' ? 'active' : '' ?>" href="communityservice.php">
                  <i class="material-icons">gavel</i>
                  <span>Kamu Hizmetindeki Oyuncular</span>
                </a>
              </li> 
              <li class="nav-item">
              <a class="nav-link <?php echo $CURRENT_PAGE== 'itemlist' ? 'active' : '' ?>" href="itemlist.php">
                  <i class="material-icons">description</i>
                  <span>Item Listesi</span>
                </a>
              </li> 
              <li class="nav-item">
              <a class="nav-link <?php echo $CURRENT_PAGE== 'vipcars' ? 'active' : '' ?>" href="vipcars.php">
                  <i class="material-icons">description</i>
                  <span>Vip Araba Listesi</span>
                </a>
              </li> 
              <li class="nav-item" >
              <a class="nav-link <?php echo $CURRENT_PAGE== 'database_bwpv' ? 'active' : '' ?>" href="database_bwpv.php">
                  <i class="material-icons">storage</i>
                  <span>(Your Server Name) Veri Tabanı</span>
                </a>
              </li>
              <li class="nav-item" >
              <a class="nav-link <?php echo $CURRENT_PAGE== 'database' ? 'active' : '' ?>" href="database.php">
                  <i class="material-icons">storage</i>
                  <span>Website Veri Tabanı</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless mt-2">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    </div>
                  </div>
                  <button type="button" class='btn btn-primary m-auto font-weight-bold'><i class="material-icons">signal_cellular_alt</i>IP : <?php echo $IP_ADDRESS; ?></button>
                  <button type="button" class='btn btn-warning m-auto font-weight-bold text-white'><i class="material-icons">admin_panel_settings</i>Yetki : <?php echo $TEXT_PERMISSION; ?></button>
                  </div>
              </form>
              <ul class="navbar-nav border-left flex-row ">
                <li class="nav-item border-right dropdown notifications">
                  <a class="nav-link nav-link-icon text-center" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="nav-link-icon__wrapper">
                      <i class="material-icons">&#xE7F4;</i>
                      <?php if($COUNT_NOTIFICATION != 0){
                        echo '<span class="badge badge-pill badge-warning" style="color:white"><b>'.$COUNT_NOTIFICATION.'</b></span>';
                      }
                      ?>
                    </div>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small" aria-labelledby="dropdownMenuLink">

                  <?php

if($COUNT_NOTIFICATION > 8){
  $COUNT_NOTIFICATION = 8;
}

for($count = 0; $count < $COUNT_NOTIFICATION; $count++){

$notification_subject = $lastnotification["$count"]['SUBJECT'];
$notification_message = $lastnotification["$count"]['MESSAGE'];
$notification_icon = $lastnotification["$count"]['ICON'];
$notification_status = $lastnotification["$count"]['STATUS'];
$notification_link = $lastnotification["$count"]['URL'];

echo "<a class='dropdown-item' href='$notification_link'>
<div class='notification__icon-wrapper'>
  <div class='notification__icon'>
    <i class='material-icons'><span class='material-icons-outlined'>$notification_icon</span></i>
  </div>
</div>
<div class='notification__content'>
  <mark class='font-weight-bold text-white'>$notification_subject</mark>
  <p class='mt-1 text-indigo'>$notification_message</p>
</div>
</a>";
}
?>

                  <!-- <a class="dropdown-item" href="#">
                      <div class="notification__icon-wrapper">
                        <div class="notification__icon">
                          <i class="material-icons"><span class="material-icons-outlined">check_circle</span></i>
                        </div>
                      </div>
                      <div class="notification__content">
                        <span class="notification__category">Everything is OK</span>
                        <p>There is no problem in the system.</p>
                      </div>
                    </a> -->

                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="<?php echo $SESSION_PROFILE_PICTURE; ?>" alt="User Avatar" width="40" height="40">
                    <span class="d-none d-md-inline-block"><?php echo $SESSION_NAME; ?>&nbsp;<?php echo $SESSION_SURNAME; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profili Düzenle</a>
                      <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-primary" href="activeaccounts.php">
                      <i class="material-icons text-primary">fact_check</i> Hesaplarım</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Çıkış Yap</a>
                      <div class="dropdown-divider"></div>
                  </div>
                </li>
              </ul>
              <nav class="nav">
              <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons"></i>
                </a>
              </nav>
            </nav>
          </div>
