<?php
ob_start();

include 'connection.php';
include 'config.php';
include 'bwpv_database.php';
include 'function.php';

/* Gerekli veriler */
$DATABASE = $_POST['DATABASE'];
$ACTION = $_POST['ACTION'];
$CSRF_TOKEN = $_POST['CSRF_TOKEN'];
$SESSION_USERNAME = $_POST['SESSION_USERNAME'];
$SESSION_PERMISSION = $_POST['SESSION_PERMISSION'];

/* CSRF_TOKEN kontrolü */
$CSRF_CHECK = decrypt($CSRF_TOKEN);
if(!$CSRF_CHECK){
    $response['error'] = 'Error : Failed to decrypt CSRF_TOKEN';
    echo json_encode($response);
    die();
}


/* EDIT */
if($ACTION == 'EDIT'){
    $DATABASE = $_POST['DATABASE'];
    $ID = $_POST['ID'];
    $SESSION_PERMISSION = $_POST['SESSION_PERMISSION'];
    if(!$ID OR !$DATABASE){
        $response['error'] = 'The transaction was aborted because the required data could not be found.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    $QUERY = $DB->query("SELECT * FROM $DATABASE WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
    if($QUERY){

        $GET_COLUMN_NAMES = $conn->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DATABASE_NAME' AND TABLE_NAME = '$DATABASE'");

        while($ROW = $GET_COLUMN_NAMES->fetch_assoc()){
            $ARRAY_COLUMN_NAMES[] = $ROW;
        }

        $COUNT_COLUMN_NAMES = count($ARRAY_COLUMN_NAMES);
        $COUNT_COLUMN_NAMES = $COUNT_COLUMN_NAMES-1;
        $response['success'] = "";
        for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
            $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
            $COLUMN_DATA = $QUERY["$COLUMN_NAME"];
            if($SESSION_PERMISSION == 'admin' OR $COLUMN_NAME != 'ID' AND $COLUMN_NAME != 'ADMIN' AND $COLUMN_NAME != 'DATE'){
                $response['success'] .= "<div class='mb-3'><label for='$COLUMN_NAME' class='form-label'>$COLUMN_NAME</label><input type='text' class='form-control' id='$COLUMN_NAME' name='$COLUMN_NAME' value='$COLUMN_DATA'></div>";
            }
        }
        $response['success'] .= "<input type='hidden' name='ID' id='ID' value='$ID'></input>";
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $response['error'] = 'Databaseye erişilemedi.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

/* EDIT_BWPV */
if($ACTION == 'EDIT_BWPV'){
    $DATABASE = $_POST['DATABASE'];
    $ID = $_POST['ID'];
    $SESSION_PERMISSION = $_POST['SESSION_PERMISSION'];
    if(!$ID OR !$DATABASE){
        $response['error'] = 'The transaction was aborted because the required data could not be found.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    $QUERY = $bwpv_pdo->query("SELECT * FROM $DATABASE WHERE id = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
    if($QUERY){

        $GET_COLUMN_NAMES = $bwpv_mysql->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$BWPV_DATABASE_NAME' AND TABLE_NAME = '$DATABASE'");

        while($ROW = $GET_COLUMN_NAMES->fetch_assoc()){
            $ARRAY_COLUMN_NAMES[] = $ROW;
        }

        $COUNT_COLUMN_NAMES = count($ARRAY_COLUMN_NAMES);

        $COUNT_COLUMN_NAMES = $COUNT_COLUMN_NAMES-1;
        $response['success'] = "";
        for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
            $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
            $COLUMN_DATA = $QUERY["$COLUMN_NAME"];
            if($SESSION_PERMISSION == 'admin' OR $COLUMN_NAME != 'id' AND $COLUMN_NAME != 'ADMIN' AND $COLUMN_NAME != 'DATE'){
                $response['success'] .= "<div class='mb-3'><label for='$COLUMN_NAME' class='form-label'>$COLUMN_NAME</label><input type='text' class='form-control' id='$COLUMN_NAME' name='$COLUMN_NAME' value='$COLUMN_DATA'></div>";
            }
        }
        $response['success'] .= "<input type='hidden' name='id' id='id' value='$ID'></input>";
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $response['error'] = 'Databaseye erişilemedi.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// TWO_FACTOR_AUTHENACTION
if($ACTION == 'TWO_FACTOR_AUTHENACTION'){
    if($_POST['ID']){
        $ID = $_POST['ID'];
    }
    else{
        if(isset($_POST['SECURITY_KEY'])){
            $SECURITY_KEY = $_POST['SECURITY_KEY'];
        }
        else{
            $QUERY_DATA = $DB->query("SELECT * FROM $DATABASE WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
            if($QUERY_DATA){
                $SECURITY_KEY = $QUERY_DATA['SECURITY_KEY'];
                $ACCOUNT_USERNAME = $QUERY_DATA['USERNAME'];
            }
            else
            {
                $response['error'] = 'Veri tabanına erişirken bir hata oluştu.';
                ob_end_clean();
                echo json_encode($response);
                die();
            }
        }
			if(empty($SECURITY_KEY)){
                $response['error'] = 'Bu hesap için iki faktörlü doğrulama sistemi ayarlanmamış.';
                ob_end_clean();
                echo json_encode($response);
                die();
            }
        $REPLACED_SECURITY_KEY = str_replace(" ", "" ,$SECURITY_KEY);
        $JSON_RESPONSE = json_decode(file_get_contents("https://2fa.live/tok/$REPLACED_SECURITY_KEY"));
        $TOKEN = $JSON_RESPONSE->token;
        $response['success'] = $TOKEN;
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}


// informations
if($ACTION == 'informations'){
    $ID = $_POST['ID'];
    if(!$ID){
        $response['error'] = 'ID bulunamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $query_account_special = $DB->query("SELECT * FROM account_special WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
        if($query_account_special){
            $informations = $query_account_special['INFORMATIONS'];
        }
        else
        {
            $response['error'] = 'Veri tabanına erişirken bir hata oluştu.';
            ob_end_clean();
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        $response['success'] = nl2br("$informations", false);
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// informations
if($ACTION == 'GET_DATA'){
    $ID = $_POST['ID'];
    $DATA = $_POST['data'];
    if(!$ID){
        $response['error'] = 'ID bulunamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    if(!$DATA){
        $response['error'] = 'Data tipi eksik gönderildi.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $QUERY = $DB->query("SELECT * FROM $DATABASE WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
        if($QUERY){
            $REQUESTED_DATA = $QUERY["$DATA"];
        }
        else
        {
            $response['error'] = 'Veri tabanına erişirken bir hata oluştu.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        if($REQUESTED_DATA == 'NULL' OR empty($REQUESTED_DATA)){
            $response['error'] = 'Maalesef burada hiçbir bilgi bulunmuyor birşeyler eklemeyi dene.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        if($DATA == 'COOKIES'){
            $response['success'] = $REQUESTED_DATA;
        }
        else{
            $response['success'] = nl2br($REQUESTED_DATA, false);
        }

        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// UPDATE_ACCOUNT_DATA
if($ACTION == 'UPDATE_ACCOUNT_DATA'){
    $ID = $_POST['ID'];
    if(!$ID){
        $response['error'] = 'Hesabın ID numarası bulunamadığı için işlem iptal ediliyor.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $query_account_special = $DB->query("SELECT * FROM account_special WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
        if($query_account_special){
            $LAST_UPDATE = $query_account_special['LAST_UPDATE'];
            $username = $query_account_special['USERNAME'];
        }
        else
        {
            $response['error'] = 'Veri tabanına erişirken bir hata oluştu';
            ob_end_clean();
            echo json_encode($response);
            die();
        }

        $time = time();
        $max_unix_time = strtotime("-1 minutes");
        $remainingtime = $LAST_UPDATE - $max_unix_time;
        if($LAST_UPDATE > $max_unix_time){
            $response['error'] = 'Güncelleme zaten yakın zamanda yapıldı lütfen '.$remainingtime.' saniye bekleyin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $update = $DB->prepare("UPDATE account_special SET LAST_UPDATE=? WHERE ID=?");
            $update->execute([$time, $ID]);
        }
    }  

    $API_RESPONSE = GET_INSTAGRAM_ACCOUNT_DATA($username);

    if(empty($API_RESPONSE) OR $API_RESPONSE == '{}'){ 
            
        $API_RESPONSE = GET_INSTAGRAM_ACCOUNT_DATA($username);
        
    }

    if(empty($API_RESPONSE) OR $API_RESPONSE == '{}'){  
        
        $response['error'] = 'Instagramdan hesabının bilgileri alınamadı. Hesabın kullanıcı adını doğru girdiğinize ve hesabın aktif halde olduğuna emin olun eğer sorun hala devam ediyorsa yazılım ekibi ile iletişime geçin. Hata Kodu : INSTAGRAM_API_ERROR_I';
        ob_end_clean();
        echo json_encode($response);
        die();
        
    }

    $JSON = json_decode($API_RESPONSE, true);
        $biography = $JSON['graphql']['user']['biography'];
        $country_block = $JSON['graphql']['user']['country_block'];
        $external_url = $JSON['graphql']['user']['external_url'];
        $edge_followed_by = $JSON['graphql']['user']['edge_followed_by']['count'];
        $edge_follow = $JSON['graphql']['user']['edge_follow']['count'];
        $full_name = $JSON['graphql']['user']['full_name'];
        $profile_id = $JSON['graphql']['user']['id'];
        $is_business_account = $JSON['graphql']['user']['is_business_account'];
        $is_professional_account = $JSON['graphql']['user']['is_professional_account'];
        $is_joined_recently = $JSON['graphql']['user']['is_joined_recently'];
        $business_address_json = $JSON['graphql']['user']['business_address_json'];
        $business_contact_method = $JSON['graphql']['user']['business_contact_method'];
        $business_email = $JSON['graphql']['user']['business_email'];
        $business_phone_number = $JSON['graphql']['user']['business_phone_number'];
        $business_category_name = $JSON['graphql']['user']['business_category_name'];
        $overall_category_name = $JSON['graphql']['user']['overall_category_name'];
        $category_name = $JSON['graphql']['user']['category_name'];
        $is_private = $JSON['graphql']['user']['is_private'];
        $is_verified = $JSON['graphql']['user']['is_verified'];
        $profile_pic_url = $JSON['graphql']['user']['profile_pic_url'];
        $profile_pic_url_hd = $JSON['graphql']['user']['profile_pic_url_hd'];
        $username = $JSON['graphql']['user']['username'];
        $should_show_public_contacts = $JSON['graphql']['user']['should_show_public_contacts'];
        $edge_owner_to_timeline_media = $JSON['graphql']['user']['edge_owner_to_timeline_media']['count'];
	    $imagepath = $profile_pic_url;
	    $imagetype = pathinfo($imagepath, PATHINFO_EXTENSION);
	    $imagedata = file_get_contents($imagepath);
	    $profile_pic_url_base64 = 'data:image/' . $imagetype . ';base64,' . base64_encode($imagedata);
        file_put_contents("../upload/$username.jpg", file_get_contents($profile_pic_url));
        $picturedirectory = "../upload/$username.jpg";
        
    if(empty($profile_id)){
        $response['error'] = 'Instagramdan hesabının bilgileri alınamadı. Hesabın kullanıcı adını doğru girdiğinize ve hesabın aktif durumda olduğuna emin olun eğer sorun hala devam ediyorsa yazılım ekibi ile iletişime geçin. Hata Kodu : INSTAGRAM_API_ERROR_II';
        ob_end_clean();
        echo json_encode($response);
        die();
    }

    $update = $DB->prepare("UPDATE account_special SET FOLLOWERS=?, FOLLOWING=?, POST=?, PROFILE_PICTURE=? WHERE ID=?");
    $update->execute([$edge_followed_by, $edge_follow, $edge_owner_to_timeline_media, "./assets/upload/$username.jpg", $ID]);

    if($update){
        LOG_USER_REQUEST($SESSION_USERNAME, "Hesabın bilgileri API aracılığı ile güncellendi ( @$username )");
        $response['success'] = 'Hesap verileri başarıyla güncellendi.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $response['error'] = 'Hesap verileri güncellenirken bir hata oluştu.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }

    ob_end_clean();
    echo json_encode($response);
    die();
}

// STATUS_ACCOUNT

if($ACTION == 'STATUS_ACCOUNT'){
	
	$ID = $_POST['ID'];
    $VALUE = $_POST['VALUE'];
	
	$BLACKLIST_STATUS_ACCOUNT = ['TRANSFER', 'SOLD', 'MAINTENANCE'];

	if($SESSION_PERMISSION != 'admin' AND in_array($VALUE, $BLACKLIST_STATUS_ACCOUNT) == 1){
		$response['error'] = 'Bu işlem sadece yönetici tarafından yapılabilir.';
		ob_end_clean();
		echo json_encode($response);
		die();
	}
	
    if(!$ID){
        $response['error'] = 'ID bilgisi alınamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    if(!$VALUE){
        $response['error'] = 'Değer bilgisi alınamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        if($VALUE == 'SOLD' OR $VALUE == 'TRANSFER'){

            if(!empty($_POST['INPUT_USERNAME'])){

                $INPUT_USERNAME = $_POST['INPUT_USERNAME'];
                $select = $DB->prepare('SELECT USERNAME FROM users WHERE USERNAME = ?');
                $select->execute([$INPUT_USERNAME]);
                if($select->rowCount() > 0){
                    
                }
                else{
                    $response['error'] = 'Sistemde böyle bir kullanıcı yok lütfen kullanıcı adını kontrol edin.';
                    ob_end_clean();
                    echo json_encode($response);
                    die();
                }

                if($VALUE == 'SOLD'){
                    $UPDATE = $DB->prepare("UPDATE account_special SET STATUS_ACCOUNT=?, OWNER=?, STATUS_SOLD=? WHERE ID=?");
                    $UPDATE->execute(['SOLD', $INPUT_USERNAME, 1, $ID]);
                    if($UPDATE){
                        $response['success'] = 'Hesap başarıyla satılmış olarak işaretlendi. Hesap @'.$INPUT_USERNAME.' kullanıcı adına sahip kullanıcıya aktarıldı.';
                        ob_end_clean();
                        echo json_encode($response);
                        die();
                    }
                    else{
                        $response['error'] = 'Hesap satılmış olarak işaretlenirken bir problem oluştu, lütfen tekrar deneyin.';
                        ob_end_clean();
                        echo json_encode($response);
                        die();
                    }
                }
                elseif($VALUE == 'TRANSFER'){
                    $UPDATE = $DB->prepare("UPDATE account_special SET OWNER=? WHERE ID=?");
                    $UPDATE->execute([$INPUT_USERNAME, $ID]);
                    if($UPDATE){
                        $response['success'] = 'Hesap başarıyla @'.$INPUT_USERNAME.' kullanıcı adına sahip kullanıcıya transfer eildi.';
                        ob_end_clean();
                        echo json_encode($response);
                        die();
                    }
                    else{
                        $response['error'] = 'Hesap transfer edilirken bir problem oluştu, lütfen tekrar deneyin.';
                        ob_end_clean();
                        echo json_encode($response);
                        die();
                    }
                }
            }
            else{
                $response['error'] = 'Bir hesabı satılmış olarak işaretlemek için hesabın yeni sahibinin kullanıcı adını göndermeniz gerek, veri alınamadı.';
                ob_end_clean();
                echo json_encode($response);
                die();
            }

        }
    }

    if($VALUE == 'ACTIVE'){
        $UPDATE = $DB->prepare("UPDATE account_special SET STATUS_ACCOUNT=? WHERE ID=?");
        $UPDATE->execute(['ACTIVE', $ID]);
        if($UPDATE){
            $response['success'] = 'Hesap başarıyla aktif edilmiş olarak işaretlendi.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $response['error'] = 'Hesap aktif edilmiş olarak işaretlenirken bir problem oluştu, lütfen tekrar deneyin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
    elseif($VALUE == 'FROZEN'){
        $UPDATE = $DB->prepare("UPDATE account_special SET STATUS_ACCOUNT=? WHERE ID=?");
        $UPDATE->execute(['FROZEN', $ID]);
        if($UPDATE){
            $response['success'] = 'Hesap başarıyla dondurulmuş olarak işaretlendi.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $response['error'] = 'Hesap dondurulmuş olarak işaretlenirken bir problem oluştu, lütfen tekrar deneyin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
    elseif($VALUE == 'MAINTENANCE'){
        $UPDATE = $DB->prepare("UPDATE account_special SET STATUS_ACCOUNT=? WHERE ID=?");
        $UPDATE->execute(['MAINTENANCE', $ID]);
        if($UPDATE){
            $response['success'] = 'Hesap başarıyla bakımda olarak işaretlendi.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $response['error'] = 'Hesap bakımda olarak işaretlenirken bir problem oluştu, lütfen tekrar deneyin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }	
}
// DELETE
if($ACTION == 'DELETE'){
    $ID = $_POST['ID'];

    if(!$ID){
        $response['error'] = 'ID Bulunamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $DELETE = $DB->exec("DELETE FROM $DATABASE WHERE ID = $ID");
        if($DELETE){
            LOG_USER_REQUEST($SESSION_USERNAME, "Belirtilen kayıtı veri tabanından sildi ['$DATABASE:$ID']");
            $response['success'] = 'Kayıt başarıyla veri tabanından silindi.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $response['error'] = 'Maalesef bilinmeyen bir hatadan dolayı kayıt silinemedi. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
}

// DELETE_BWPV
if($ACTION == 'DELETE_BWPV'){
    $ID = $_POST['ID'];

    if(!$ID){
        $response['error'] = 'ID Bulunamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        if($DATABASE == 'communityservice'){
            $DELETE = $bwpv_pdo->exec("DELETE FROM $DATABASE WHERE actions_remaining = $ID");
        } else {
            $DELETE = $bwpv_pdo->exec("DELETE FROM $DATABASE WHERE id = $ID");
        }
        if($DELETE){
            LOG_USER_REQUEST($SESSION_USERNAME, "Belirtilen kayıtı veri tabanından sildi ['$DATABASE:$ID']");
            $response['success'] = 'Kayıt başarıyla veri tabanından silindi.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $response['error'] = 'Maalesef bilinmeyen bir hatadan dolayı kayıt silinemedi. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
}

// DELETE_ALL_BWPV
if($ACTION == 'DELETE_ALL_BWPV'){
    $BLACKLISTED_DATABASE = ['users', 'vusca_banlist'];
    /* if(in_array($DATABASE, $BLACKLISTED_DATABASE)){
        $response['error'] = 'Bu veri tabanını toplu olarak silemezsiniz.';
        ob_end_clean();
        echo json_encode($response);
        die();
    } */
    if($SESSION_PERMISSION == 'admin'){
        $DELETE = $DB->exec("DELETE FROM $DATABASE");
        if ($DELETE) {
            LOG_USER_REQUEST($SESSION_USERNAME, "Veri tabanını temizledi ['$DATABASE:DELETE_ALL']");
            $response['success'] = 'Tüm veriler başarıyla veri tabanından silindi.';
            ob_end_clean();
            echo json_encode($response);
            die();
        } else {
            $response['error'] = 'Veri tabanı silinirken bir hata oluştu. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
    else{
        $response['error'] = 'Bu işlemi yapmaya yetkiniz bulunmuyor. Yetki almak için lütfen sistem yöneticisi ile iletişime geçin.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// ADD_TO_BLACKLIST
if($ACTION == 'ADD_TO_BLACKLIST'){

    if($SESSION_PERMISSION != 'admin'){
        $response['error'] = "Bu işlemi sadece yöentici gerçekleştirebilir, işlemi iptal edin veya izin almak için lütfen sistem yöneticisi ile iletişime geçin.";
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    
    $VALUE = $_POST['VALUE'];

    if(!$VALUE){
        $response['error'] = 'Geçersiz bir değer gönderildi.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $ADD_TO_BLACKLIST = ADD_TO_BLACKLIST($DATABASE, $VALUE);
        if($ADD_TO_BLACKLIST == 1){
            LOG_USER_REQUEST($SESSION_USERNAME, "Blackliste yeni bir kayıt ekledi. ['$DATABASE:$VALUE']");
            $response['success'] = "$VALUE başarıyla $DATABASE veri tabanına eklendi.";
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $response['error'] = 'Maalesef bilinmeyen bir hatadan dolayı kayıt blackliste eklenemedi. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
}

// DELETE_ACCOUNT
if($ACTION == 'DELETE_ACCOUNT'){

    $VALUE = $_POST['VALUE'];
    if(!$VALUE){
        $response['error'] = 'Geçersiz bir değer gönderildi.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    
    if($SESSION_PERMISSION == 'admin'){
        $QUERY_DATABASE = $DB->prepare("SELECT * FROM `$DATABASE` WHERE USERNAME=?");
        $QUERY_DATABASE->execute([$VALUE]);
        $QUERY_CHECK = $QUERY_DATABASE->rowCount();
    }
    else{
        $QUERY_DATABASE = $DB->prepare("SELECT * FROM `$DATABASE` WHERE USERNAME=? AND OWNER=?");
        $QUERY_DATABASE->execute([$VALUE, $SESSION_USERNAME]);
        $QUERY_CHECK = $QUERY_DATABASE->rowCount();
    }

    if($QUERY_CHECK == 1){

        $GET_COLUMN_NAMES = $conn->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '$DATABASE_NAME' AND TABLE_NAME = '$DATABASE'");
        while($ROW = $GET_COLUMN_NAMES->fetch_assoc()){
            $ARRAY_COLUMN_NAMES[] = $ROW;
        }
        $COUNT_COLUMN_NAMES = count($ARRAY_COLUMN_NAMES);
        $COUNT_COLUMN_NAMES = $COUNT_COLUMN_NAMES-1;
    
        $SQL = "INSERT INTO `account_deleted` SET";
        $ARRAY = array();

        foreach( $QUERY_DATABASE as $ROW ){
            $ACCOUNT_ID = $ROW['ID'];
            for($i = 0; $i <= $COUNT_COLUMN_NAMES; $i++){
              $COLUMN_NAME = $ARRAY_COLUMN_NAMES[$i]['COLUMN_NAME'];
              $SQL = $SQL." $COLUMN_NAME = ?,";
              $COLUMN_VALUE = $ROW[$COLUMN_NAME];
              array_push($ARRAY, $COLUMN_VALUE);
            }
        }

        $SQL = substr($SQL,0,-1);
        $INSERT = $DB->prepare($SQL);
        $INSERT = $INSERT->execute($ARRAY);
        if($INSERT){
            $DELETE = $DB->exec("DELETE FROM account_special WHERE ID = $ACCOUNT_ID");
            if($DELETE){
                LOG_USER_REQUEST($SESSION_USERNAME, "Hesap veri tabanından silindi ['$DATABASE:$VALUE']");
                $response['success'] = 'Hesap başarıyla veri tabanından silindi.';
                ob_end_clean();
                echo json_encode($response);
                die();
            }
            else{
                $response['error'] = "Hesap veri tabanından silinmeye çalışılırken bir hata oluştu lütfen tekrar deneyin.";
                ob_end_clean();
                echo json_encode($response);
                die();
            }
        }
        else{
            $response['error'] = "Hesap veri tabanından silinmeye çalışılırken bir hata oluştu lütfen tekrar deneyin.";
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
    else{
        $response['error'] = "asddas.";
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// CREATE_LICENSE
if($ACTION == 'CREATE_LICENSE'){

if($SESSION_USERNAME != 'admin'){
    $response['error'] = 'Bu işlemi yapmaya yetkiniz bulunmuyor. Yetki almak için lütfen sistem yöneticisi ile iletişime geçin.';
    ob_end_clean();
    echo json_encode($response);
    die();
}

$LICENSE = GENERATE_PASSWORD('14');
$QUERY_LICENSE = $DB->prepare("INSERT INTO license SET license = ?, admin = ?, date = ?");
$INSERT_LICENSE = $QUERY_LICENSE->execute(array($LICENSE, $SESSION_USERNAME, $UNIX_DATE_AND_TIME));
    if($INSERT_LICENSE){
        LOG_USER_REQUEST($SESSION_USERNAME, "Yeni bir lisans oluşturdu ['$DATABASE:$LICENSE']");
        $response['success'] = $LICENSE;
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $response['error'] = 'Maalesef bilinmeyen bir hatadan dolayı lisans oluşturulamadı. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// SUSPEND
if($ACTION == 'SUSPEND'){
    $ID = $_POST['ID'];
    if(!$ID){
        $response['error'] = 'ID Bulunamadı.';
        echo json_encode($response);
    }
    else{
        $QUERY_USERS = $DB->query("SELECT * FROM users WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);

        if($QUERY_USERS['suspend'] == 1){
            $NEW_SUSPEND_STATUS = 0;
        }
        else{
            $NEW_SUSPEND_STATUS = 1;
        }
    
        $UPDATE = $DB->prepare("UPDATE $DATABASE SET suspend=? WHERE ID=?");
        $UPDATE->execute([$NEW_SUSPEND_STATUS, $ID]);
        if($UPDATE){
            LOG_USER_REQUEST($SESSION_USERNAME, "Hesap devre dışı bırakıldı ( $DATABASE -> $ID )");
            if($NEW_SUSPEND_STATUS == 1){
               $response['success'] = 'Kullanıcının hesabı devre dışı bırakıldı siz tekrar aktifleştirene kadar hesabına giriş yapamıyacak.';
            }
            elseif($NEW_SUSPEND_STATUS == 0){
               $response['success'] = 'Kullanıcının hesabı tekrardan aktifleştirildi. Kullanıcı hesabına giriş yapabilir.';
            }
            else{
                $response['error'] = 'Geçersiz parametre, lütfen AJAX sistemini kontrol edin veri tabanına geçersiz bir veri girildi.';
            }
            
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        else{
            $response['error'] = 'Maalesef bilinmeyen bir hatadan dolayı kullanıcı devre dışı bırakılamadı. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
}

// DELETE_ALL
if($ACTION == 'DELETE_ALL'){
    $BLACKLISTED_DATABASE = ['users', 'account_special'];
    if(in_array($DATABASE, $BLACKLISTED_DATABASE)){
        $response['error'] = 'Bu veri tabanını toplu olarak silemezsiniz.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    if($SESSION_PERMISSION == 'admin'){
        $DELETE = $DB->exec("DELETE FROM $DATABASE");
        if ($DELETE) {
            LOG_USER_REQUEST($SESSION_USERNAME, "Veri tabanını temizledi ['$DATABASE:DELETE_ALL']");
            $response['success'] = 'Tüm veriler başarıyla veri tabanından silindi.';
            ob_end_clean();
            echo json_encode($response);
            die();
        } else {
            $response['error'] = 'Veri tabanı silinirken bir hata oluştu. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
    }
    else{
        $response['error'] = 'Bu işlemi yapmaya yetkiniz bulunmuyor. Yetki almak için lütfen sistem yöneticisi ile iletişime geçin.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// changesettings
if($ACTION == 'changesettings'){
    $value = $_POST['value'];
    $DATABASE_settings = "UPDATE settings SET value=? WHERE name=?";
    $ACTION_change_settings = $DB->prepare($DATABASE_settings)->execute([$value, $DATABASE]);
    if($ACTION_change_settings){
        $response['success'] = "Ayar başarıyla değiştirildi yeni ayar sisteme eklendi.";
        LOG_USER_REQUEST($SESSION_USERNAME, "Bir ayar değiştirdi ( $DATABASE -> $value )");
    }
    else{
        $response['error'] = "Bir hatadan dolayı ayar değiştirilemedi. Lütfen tekrar deneyin veya sistem yöneticisi ile iletişime geçin.";
    }

}

// recoverycodes
if($ACTION == 'recoverycodes'){
    $ID = $_POST['ID'];
    if(!$ID){
        $response['error'] = 'ID Bulunamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $query_account_special = $DB->query("SELECT * FROM $DATABASE WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
        if($query_account_special){
            $recoverycodes = $query_account_special['recoverycodes'];
        }
        else
        {
            $response['error'] = 'Veri tabanına erişirken bir hata oluştu.';
            ob_end_clean();
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        if($recoverycodes == 'NULL' OR empty($recoverycodes)){
            $response['error'] = 'Bu hesaba ait yedek kod bilgisi eklenmemiş.';
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        $response['success'] = $recoverycodes;
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

// LOGS
if($ACTION == 'LOGS'){
    $ID = $_POST['ID'];
    if(!$ID){
        $response['error'] = 'ID bulunamadı.';
        ob_end_clean();
        echo json_encode($response);
        die();
    }
    else{
        $query_account_special = $DB->query("SELECT * FROM account_special WHERE ID = '{$ID}'")->fetch(PDO::FETCH_ASSOC);
        if($query_account_special){
            $LOGS = $query_account_special['LOGS'];
        }
        else
        {
            $response['error'] = 'Veri tabanına erişilemedi.';
            ob_end_clean();
            ob_end_clean();
            echo json_encode($response);
            die();
        }
        $response['success'] = nl2br("$LOGS", false);
        ob_end_clean();
        echo json_encode($response);
        die();
    }
}

$response['error'] = 'Yapılmak istenilen işlem AJAX sisteminde bulunmuyor. Lütfen sistem yöneticisi veya yazılım ekibi ile iletişime geçin';
ob_end_clean();
echo json_encode($response);
die();
?>