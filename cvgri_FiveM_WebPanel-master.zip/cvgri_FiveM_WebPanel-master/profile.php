<?php

$PERMISSION = ['admin', 'master', 'moderator', 'support'];
$CURRENT_PAGE = 'profile';
$FILE_NAME = $CURRENT_PAGE.'.php';
$PAGE_TITLE = 'Profili Düzenle';

include './assets/php/connection.php';
include './assets/php/function.php';
include './assets/php/header.php';

ob_start();
?>

<!doctype html>
<html class="no-js h-100" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $PAGE_TITLE; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php 
    $CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $PERMISSION);
    if($CHECK_PERMISSION == 0){
        include './assets/php/footer.php'; 
        die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_PERMISSION, "Tamam", 0, 0, 0));
    }
?>

          <?php if(isset($message)){
            echo '<div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
            <i class="fa fa-check mx-2"></i><strong>'.$message.'</strong> You are being redirected.</div>';
            session_destroy();
            echo '<meta http-equiv="Refresh" content="4; url=index.php">';
          } ?>
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <button type="button" class="btn mt-4 mb-4 text-white font-weight-bold" style="background-color: #FF6100"><?php echo $PAGE_TITLE; ?></button>
            <!-- End Page Header -->
            <!-- Default Light Table -->
            <div class="row">
              <div class="col-lg-4">
                <div class="card card-small mb-4 pt-3">
                  <div class="card-header border-bottom text-center">
                    <div class="mb-3 mx-auto">
                      <img class="rounded-circle" src="<?php echo $SESSION_PROFILE_PICTURE; ?>" alt="User Avatar" width="110" height="110"></div>
                    <h4 class="mb-0"><?php echo $SESSION_NAME; ?>&nbsp;<?php echo $SESSION_SURNAME; ?></h4>
                    <span class="text-muted d-block mb-2">Sizi görmek güzel, efendim.</span>
                    <button data-toggle="modal" data-target="#changeprofilepicture" class="mb-2 btn btn-sm btn-pill btn-outline-primary mr-2"><i class="material-icons mr-1">file_upload</i>Profil Fotoğrafını Değiştir</button>
                  </div>

                  <ul class="list-group list-group-flush">
                    <li class="list-group-item px-4">
                      <div class="progress-wrapper">
                        <?php 
                        if($SESSION_PERMISSION == 'admin'){
                          $progress_value = '100';
                          $progress_color = 'danger';
                        }
                        elseif($SESSION_PERMISSION == 'master'){
                          $progress_value = '80';
                          $progress_color = 'warning';
                        }
                        elseif($SESSION_PERMISSION == 'moderator'){
                          $progress_value = '60';
                          $progress_color = 'warning';
                        }
                        elseif($SESSION_PERMISSION == 'customer'){
                          $progress_value = '40';
                          $progress_color = 'primary';
                        }
                        else{
                          $progress_value = '20';
                          $progress_color = 'success';
                        }
                        
                        ?> 
                        <strong class="text-muted d-block mb-2">Yetki Düzeyi</strong>
                        <div class="progress progress-sm">
                          <div class="progress-bar bg-<?php echo $progress_color; ?>" role="progressbar" aria-valuenow="<?php echo $progress_value; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $progress_value; ?>%;">
                            <span class="progress-value"><?php echo $progress_value; ?>%</span>
                          </div>
                        </div>
                      </div>
                    </li>

                    <li class="list-group-item p-4">
                      <strong class="text-muted d-block mb-2">Hesap Bilgileri</strong>
                      <span>
                      <strong>Ad :</strong> <?php echo $SESSION_NAME; ?><br>
                      <strong>Soyad :</strong> <?php echo $SESSION_SURNAME; ?><br>
                      <strong>Kullanıcı Adı :</strong> <?php echo $SESSION_USERNAME; ?><br>
                      <strong>Son Giriş Tarihi :</strong> <?php echo EPOCH_CONVERTER($SESSION_DATE); ?><br>
                      <strong>IP Adresi :</strong> <?php echo $IP_ADDRESS; ?><br>
                      <strong>User Agent :</strong> <?php echo $USER_AGENT; ?><br>
                      <strong>Ülke :</strong> <?php echo $SESSION_COUNTRY; ?><br>
                      <strong>Internet Servis Sağlayıcısı :</strong> <?php echo $SESSION_ISP; ?><br>
                      <strong>Kurtarma Emaili :</strong>
                      <?php 
                      if(!empty($SESSION_RECOVERY_EMAIL) OR $SESSION_RECOVERY_EMAIL != 0){
                        echo $SESSION_RECOVERY_EMAIL;
                      }
                      else{
                        echo "-";
                      }
                      ?>
                      <br>
                      <strong>Kurtarma Telefon Numarası :</strong> 
                      <?php 
                      if(!empty($SESSION_RECOVERY_PHONE_NUMBER) OR $SESSION_RECOVERY_PHONE_NUMBER != 0){
                        echo $SESSION_RECOVERY_PHONE_NUMBER;
                      }
                      else{
                        echo "-";
                      }
                      ?>
                      <br>
                    </span>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-8">
                <div class="card card-small mb-4">
                  <div class="card-header border-bottom">
                    <h6 class="m-0">Hesap Detayları</h6>
                  </div>
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item p-3">
                      <div class="row">
                        <div class="col">
                          <form action="" method="post">
                            <div class="form-row">
                              <div class="form-group col-md-6">
                                <label for="input_admin_name">Ad</label>
                                <input type="text" class="form-control" id="input_admin_name" name="input_admin_name" placeholder="<?php echo $SESSION_NAME; ?>" placeholder="<?php echo $SESSION_NAME; ?>"> </div>
                              <div class="form-group col-md-6">
                                <label for="input_admin_surname">Soyad</label>
                                <input type="text" class="form-control" id="input_admin_surname" name="input_admin_surname" placeholder="<?php echo $SESSION_SURNAME; ?>" placeholder="<?php echo $SESSION_SURNAME; ?>"> </div>
                            </div>
                            <div class="form-group">
                              <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                  <span class="input-group-text" id="basic-addon1">@</span>
                                </div>
                                <input type="text" class="form-control is-valid" name="input_admin_username" placeholder="<?php echo $SESSION_USERNAME; ?>" value="<?php echo $SESSION_USERNAME; ?>" readonly> </div>
                            </div>
                            <ul class="list-group list-group-flush">
                            <label for="input_old_password">Eski Şifre</label>
                            <div class="input-group mb-3">
                          <div class="input-group input-group-seamless">
                            <input type="password" class="form-control" id="input_old_password" name="input_old_password" placeholder="Eski Şifre">
                            <span class="input-group-append">
                              <span class="input-group-text">
                                <i class="material-icons">lock</i>
                              </span>
                            </span>
                          </div>
                        </div>
                        <label for="input_new_password">Yeni Şifre</label>
                            <div class="input-group mb-3">
                          <div class="input-group input-group-seamless">
                            <input type="password" class="form-control" id="input_new_password" name="input_new_password" placeholder="Yeni Şifre" minlength="6">
                            <span class="input-group-append">
                              <span class="input-group-text">
                                <i class="material-icons">lock</i>
                              </span>
                            </span>
                          </div>
                        </div>
                        <label for="RECOVERY_EMAIL">Kurtarma Emaili</label>
                        <div class="form-group">
                          <div class="input-group mt-1 mb-1">
                            <div class="input-group-prepend">
                              <span class="input-group-text material-icons">mail</span>
                            </div>
                            <input type="text" class="form-control" name="INPUT_RECOVERY_EMAIL" id="INPUT_RECOVERY_EMAIL" placeholder="<?php echo $SESSION_RECOVERY_EMAIL; ?>"> </div>
                        </div>
                        <label for="RECOVERY_PHONE_NUMBER">Kurtarma Telefon Numarası</label>
                        <div class="form-group">
                          <div class="input-group mb-1">
                            <div class="input-group-prepend">
                             <span class="input-group-text material-icons">phone</span>
                            </div>
                            <input type="text" class="form-control" name="INPUT_RECOVERY_PHONE_NUMBER" id="INPUT_RECOVERY_PHONE_NUMBER" placeholder="<?php echo $SESSION_RECOVERY_PHONE_NUMBER; ?>"> </div>
                        </div>
                            <button type="submit" name="BUTTON_UPDATE_ACCOUNT_INFORMATION" class="btn btn-accent">Bilgileri Güncelle</button>
                          </form>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
<?php 

include './assets/php/footer.php'; 

if(isset($_POST['BUTTON_CHANGE_PROFILE_PICTURE'])){

    $target_dir = "./assets/images/users/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    if(isset($_POST["submit"])) {
      $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
      if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
      } else {
        echo SWEET_ALERT("error", "Başarısız", "Bu bir fotoğraf dosyası değil lütfen bir fotoğraf dosyası gönderin.", "Tamam", "Sadece JPG, JPEG, PNG & GIF dosyalarını kabul ediyoruz.", 0, "profile.php");
        $uploadOk = 0;
      }
    }

    if (file_exists($target_file)) {
      echo SWEET_ALERT("error", "Başarısız", "Fotoğraf zaten hali hazırda var lütfen başka bir fotoğraf yükle.", "Tamam", 0, 0, "profile.php");
      $uploadOk = 0;
    }

    if ($_FILES["fileToUpload"]["size"] > 5000000) {
      echo SWEET_ALERT("error", "Başarısız", "Fotoğrafın boyutu çok büyük lütfen daha küçük bir resim yükle.", "Tamam", "En fazla 1MB boyutunda resim yükleyebilirsin.", 0, "profile.php");
      $uploadOk = 0;
    }

    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif"){
      echo SWEET_ALERT("error", "Başarısız", "Bu bir kabul ettiğimiz cinsten fotoğraf dosyası değil lütfen bir fotoğraf dosyası gönderin.", "Tamam", "Sadece JPG, JPEG, PNG & GIF dosyalarını kabul ediyoruz.", 0, "profile.php");
      $uploadOk = 0;
    }

    if ($uploadOk == 0) {
      echo SWEET_ALERT("error", "Başarısız", "Üzgünüz, bir hata nedeniyle fotoğrafınızı yükleyemedik lütfen tekrar deneyin.", "Tamam", 0, 0, "profile.php");
    } 
    else{
      $imagepath = "$target_dir$SESSION_USERNAME.$imageFileType";
      if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $imagepath)){
      $UPDATE_USERS = "UPDATE users SET PROFILE_PICTURE=? WHERE ID=?";
      $PROCESS_CHANGE_PROFILE_PICTURE = $DB->prepare($UPDATE_USERS)->execute([$imagepath, $SESSION_ID]);
      LOG_USER_REQUEST($SESSION_USERNAME, 'Profil fotoğrafını değiştirdi.');
      echo SWEET_ALERT("success", "Başarılı", "Profil fotoğrafı başarıyla güncellendi.", "Tamam", "Tarayıcı kaynaklı olarak profil fotoğrafının değişmesi belirli bir süre alabilir çerezleri temizlediğinizde problem ortadan kalkacaktır.", 0, "profile.php");
      } else {
        echo SWEET_ALERT("error", "Başarısız", "Üzgünüz, bir hata nedeniyle fotoğrafınızı yükleyemedik lütfen tekrar deneyin.", "Tamam", 0, 0, "profile.php");
      }
    }
  } 
  
  if(isset($_POST['BUTTON_UPDATE_ACCOUNT_INFORMATION'])){
    $old_password = htmlspecialchars($_POST['input_old_password']);
    $new_password = htmlspecialchars($_POST['input_new_password']);
    $new_admin_name = htmlspecialchars($_POST['input_admin_name']);
    $new_admin_surname = htmlspecialchars($_POST['input_admin_surname']);
    $INPUT_RECOVERY_EMAIL = htmlspecialchars($_POST['INPUT_RECOVERY_EMAIL']);
    $INPUT_RECOVERY_PHONE_NUMBER = htmlspecialchars($_POST['INPUT_RECOVERY_PHONE_NUMBER']);
    $INPUT_RECOVERY_PHONE_NUMBER = str_replace(" ","",$INPUT_RECOVERY_PHONE_NUMBER);

    if(!isset($old_password) AND !isset($new_password) AND !isset($new_admin_name) AND !isset($new_admin_surname)){
        echo "<script>alert('haha')</script>";
        SWEET_ALERT("error", "Başarısız", "Hesap bilgilerini değiştirebilmek için en az bir değer girmeniz gerekiyor.", 0, 0, 0, "profile.php");
        die();
    }

    if(!empty($new_password)){
      if(empty($old_password)){
        echo SWEET_ALERT("error", "Başarısız", "Şifrenizi değiştirmek için eski şifrenizi girmeniz gerekiyor.", 0, 0, 0, "profile.php");
        die();
      }
      else{
        if($old_password == DECRYPT($SESSION_PASSWORD)){
          $CHANGE_PASSWORD = 1;
        }
        else{
          echo SWEET_ALERT("error", "Başarısız", "Eski şifrenizi yanlış girdiniz, şifreyi değiştirebilmek için eski şifreyi doğru girmelisiniz.", 0, 0, 0, "profile.php");
          die();
        }
      }
    }

    if(!empty($new_admin_name)){
      if($new_admin_name == $SESSION_NAME){
        echo SWEET_ALERT("error", "Başarısız", "Yeni adınız eski adınız ile aynı olamaz.", 0, 0, 0, "profile.php");
        die();
      }
      else{
        $CHANGE_NAME = 1;
      }
    }

    if(!empty($new_admin_surname)){
      if($new_admin_surname == $SESSION_SURNAME){
        echo SWEET_ALERT('error', 'Başarısız', 'Yeni soyadınız eski soyadınız ile aynı olamaz.', 'Tamam', 0, 0, 'profile.php');
        die();
      }
      else{
        $CHANGE_SURNAME = 1;
      }
    }

    if(!empty($INPUT_RECOVERY_EMAIL)){
      if($INPUT_RECOVERY_EMAIL == $SESSION_RECOVERY_EMAIL){
        echo SWEET_ALERT('error', 'Başarısız', 'Yeni kurtarma emaili ile eski kurtarma emaili aynı olamaz.', 'Tamam', 0, 0, 'profile.php');
        die();
      }
      else{
        if($old_password == DECRYPT($SESSION_PASSWORD)){
          $CHANGE_RECOVERY_EMAIL = 1;
        }
        else{
          echo SWEET_ALERT('error', 'Başarısız', 'Kurtarma bilgisini değiştirmek için eski şifrenizi doğru bir biçimde hesap detaylarında bulunan alana girmeniz gerekiyor.', 'Tamam', 0, 0, 'profile.php');
          die();
        }
      }
    }

    if(!empty($INPUT_RECOVERY_PHONE_NUMBER)){
      if($INPUT_RECOVERY_PHONE_NUMBER == $SESSION_RECOVERY_PHONE_NUMBER){
        echo SWEET_ALERT('error', 'Başarısız', 'Yeni kurtarma telefon numarası ile eski kurtarma telefon numarası ile aynı olamaz.', 'Tamam', 0, 0, 'profile.php');
        die();
      }
      else{
        if($old_password == DECRYPT($SESSION_PASSWORD)){
          $CHANGE_RECOVERY_PHONE_NUMBER = 1;
        }
        else{
          echo SWEET_ALERT('error', 'Başarısız', 'Kurtarma bilgisini değiştirmek için eski şifrenizi doğru bir biçimde hesap detaylarında bulunan alana girmeniz gerekiyor.', 'Tamam', 0, 0, 'profile.php');
          die();
        }
      }
    }

    $MESSAGE = "";

    if(isset($CHANGE_PASSWORD) AND $CHANGE_PASSWORD == 1){
      $ENCYRPTED_NEW_PASSWORD = ENCRYPT($new_password);
      $SQL = "UPDATE users SET PASSWORD=? WHERE ID=?";
      $UPDATE = $DB->prepare($SQL)->execute([$ENCYRPTED_NEW_PASSWORD, $SESSION_ID]);
      $MESSAGE .= "Şifre bilgisi değiştirildi. ";
      LOG_USER_REQUEST($SESSION_USERNAME, "Hesap şifresini değiştirdi.");
    }
    if(isset($CHANGE_NAME) AND $CHANGE_NAME == 1){
      $SQL = "UPDATE users SET NAME=? WHERE ID=?";
      $UPDATE = $DB->prepare($SQL)->execute([$new_admin_name, $SESSION_ID]);
      $MESSAGE .= "Ad bilgisi değiştirildi. ";
      LOG_USER_REQUEST($SESSION_USERNAME, "Ad bilgisini değiştirdi.\nEski Ad : $SESSION_NAME"."\nYeni Ad : $new_admin_name");
    }
    if(isset($CHANGE_SURNAME) AND $CHANGE_SURNAME == 1){
      $ENCYRPTED_NEW_PASSWORD = ENCRYPT($new_password);
      $SQL = "UPDATE users SET SURNAME=? WHERE ID=?";
      $UPDATE = $DB->prepare($SQL)->execute([$new_admin_surname, $SESSION_ID]);
      $MESSAGE .= "Soyad bilgisi değiştirildi. ";
      LOG_USER_REQUEST($SESSION_USERNAME, "Soyad bilgisini değiştirdi.\nEski Soyad : $SESSION_SURNAME"."\nYeni Soyad : $new_admin_surname");
    }
    if(isset($CHANGE_RECOVERY_EMAIL) AND $CHANGE_RECOVERY_EMAIL == 1){
      $SQL = "UPDATE users SET RECOVERY_EMAIL=? WHERE ID=?";
      $UPDATE = $DB->prepare($SQL)->execute([$INPUT_RECOVERY_EMAIL, $SESSION_ID]);
      $MESSAGE .= "Kurtarma emaili bilgisi değiştirildi. ";
      LOG_USER_REQUEST($SESSION_USERNAME, "Kurtarma emailini değiştirdi.\nEski Kurtarma Emaili : $SESSION_RECOVERY_EMAIL"."\nYeni Kurtarma Emaili : $INPUT_RECOVERY_EMAIL");
    }
    if(isset($CHANGE_RECOVERY_PHONE_NUMBER) AND $CHANGE_RECOVERY_PHONE_NUMBER == 1){
      $SQL = "UPDATE users SET RECOVERY_PHONE_NUMBER=? WHERE ID=?";
      $UPDATE = $DB->prepare($SQL)->execute([$INPUT_RECOVERY_PHONE_NUMBER, $SESSION_ID]);
      $MESSAGE .= "Kurtarma telefon numarasi bilgisi değiştirildi. ";
      LOG_USER_REQUEST($SESSION_USERNAME, "Kurtarma telefon numarasını değiştirdi.\nEski Kurtarma Emaili : $SESSION_RECOVERY_PHONE_NUMBER"."\nYeni Kurtarma Emaili : $INPUT_RECOVERY_PHONE_NUMBER");
    }

    if(!empty($MESSAGE)){
      echo SWEET_ALERT('success', 'Başarılı', 'Hesabınızla ilgili istenilen bilgiler başarıyla değiştirildi.', 'Tamam', "Yapılan İşlemler : $MESSAGE", 0, 'profile.php');
      die();
    }
    else{
      echo SWEET_ALERT("error", "Başarısız", "Lütfen hesap bilgilerini değiştirmek için her hangi bir bilgi girin.", "Tamam", 0, 0, "profile.php");
      die();
    }

}

?>
</body>
</html>

<!-- Modal -->
<div class="modal fade" id="changeprofilepicture" tabindex="-1" role="dialog" aria-labelledby="changeprofilepicture" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="changeprofilepicture">Profil Fotoğrafını Değiştir</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <form action="" method="post" enctype="multipart/form-data">
      <input type="file" name="fileToUpload" id="fileToUpload" >
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kapat</button>
        <button type="submit" name="BUTTON_CHANGE_PROFILE_PICTURE" class="btn btn-primary">Profil Fotoğrafını Değiştir</button>
      </div>
    </div>
  </div>
</div>
