<?php

$PERMISSION = ['admin', 'master'];
$CURRENT_PAGE = 'realitybanlist';
$FILE_NAME = $CURRENT_PAGE.'.php';
$PAGE_TITLE = 'CVGRI Yasaklama Listesi';

include './assets/php/connection.php';
include './assets/php/bwpv_database.php';
include './assets/php/function.php';
include './assets/php/header.php';

if(!empty($_GET['PAGE'])){
  $PAGE = $_GET['PAGE'];
}
else{
  if(empty($_GET['ACTION'])){
    header("refresh:0;url=$FILE_NAME?PAGE=1");
  }
}

ob_start();

if($_GET['ACTION'] == 'EDIT'){
  $ID = $_GET['ID'];
  $CSRF_TOKEN = $_GET['CSRF_TOKEN'];

if(empty($ID) OR empty($CSRF_TOKEN)){
  session_destroy();
  echo 'Tüm bilgiler alınamadığı için işlem iptal edildi, oturumunuz kapatılıyor.';
  die(SWEET_ALERT("error", "Erişim Engellendi", "Tüm bilgiler alınamadığı için işlem iptal edildi, oturumunuz kapatılıyor.", "Tamam", "Giriş Yap", "login.php", "login.php"));
}

$CSRF_CHECK = DECRYPT($CSRF_TOKEN);
if(!$CSRF_CHECK){
  session_destroy();
  echo $DIE_CSRF_TOKEN;
  die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_CSRF_TOKEN, "Tamam", "Giriş Yap", "login.php", "login.php"));
}

$STATUS = true;
$bwpv_banlist = $bwpv_pdo->query("SELECT * FROM reality_banlist WHERE id = '{$ID}'")->fetch(PDO::FETCH_ASSOC);

if($SESSION_PERMISSION == 'admin'){
  $WHITELIST = true;
}
else{
if($bwpv_banlist['OWNER'] != $SESSION_USERNAME){
  session_destroy();
  header("refresh:10;url=login.php");
  echo 'Bu email adresi sana ait değil, tekrardan bu tür bir girişimde bulunursan sistemden yasaklanacaksın. Şimdilik oturumun sonlandırılıyor yönlendiriliyorsun.';
  echo SWEET_ALERT('error', 'Erişim Engellendi', 'Bu email adresi sana ait değil, tekrardan bu tür bir girişimde bulunursan sistemden yasaklanacaksın. Şimdilik oturumun sonlandırılıyor yönlendiriliyorsun.', 'Tamam', 0, 0, 'login.php');
}
}
}
?>

<!doctype html>
<html class="no-js h-100" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>CVGRI Yasaklama Listesi ( @
      <?php echo $bwpv_banlist['steam']; ?> )
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<?php 

$CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $PERMISSION);

if($CHECK_PERMISSION == 0){
  include './assets/php/footer.php'; 
  die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_PERMISSION, "Tamam", 0, 0, $FILE_NAME));
}

?>

    <div class="main-content-container container-fluid px-4">

      <!-- PAGE HEADER -->
      <button type="button" style="background-color: #FF6100" class="btn mt-4 mb-4 text-white font-weight-bold">
        <?php echo $PAGE_TITLE; ?>
      </button>
      <!-- PAGE HEADER -->

    <table class="table bg-danger text-white mt-4">
  <thead>
    <tr>
      <?php
      echo '<th>Steam Hex</th><th>Discord</th><th>Yasaklanma Nedeni</th><th>Yasaklandığı Zaman</th><th>Yasağın Biteceği Zaman</th>';
      ?>
    </tr>
  </thead>
  <tbody>
  <tr>

    <?php 
    echo 
    '<td>'.$bwpv_banlist['steam'].'</td>
    <td>'.$bwpv_banlist['discord'].'</td>
    <td>'.$bwpv_banlist['reason'].'</td>
    <td>'.EPOCH_CONVERTER($bwpv_banlist['banned_date']).'</td>
    <td>'.EPOCH_CONVERTER($bwpv_banlist['finish_date']).'</td>';
    ?>
    </table>

    <div class="card card-small">
      <div class="card-header border-bottom">
        <h6 class="m-0">Lütfen değiştirmek istediğiniz bilgileri girin.</h6>
      </div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item p-3">
          <div class="row">
            <div class="col">
              <form method="POST">

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="steam">Steam Hex
                    </label>
                    <input type="text" class="form-control" id="steam" name="steam" value="<?php echo $bwpv_banlist['steam']; ?>">
                  </div>

                  <div class="form-group col-md-6">
                    <label for="license">Rockstar Lisansı
                    </label>
                    <input type="text" class="form-control" id="license" name="license" value="<?php echo $bwpv_banlist['license']; ?>">
                  </div>
                  </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="xbl">Xbox Lisansı
                    </label>
                    <input type="text" class="form-control" id="xbl" name="xbl" value="<?php echo $bwpv_banlist['xbl']; ?>">
                  </div>

                  <div class="form-group col-md-6">
                    <label for="discord">Discord
                    </label>
                    <input type="text" class="form-control" id="discord" name="discord" value="<?php echo $bwpv_banlist['discord']; ?>">
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="live">Live Lisansı
                    </label>
                    <input type="text" class="form-control" id="live" name="live" value="<?php echo $bwpv_banlist['liveid']; ?>">
                  </div>

                  <div class="form-group col-md-6">
                    <label for="ip">IP Adresi
                    </label>
                    <input type="text" class="form-control" id="ip" name="ip" value="<?php echo $bwpv_banlist['ip']; ?>">
                  </div>
                </div>

                <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="token">FiveM Token
                    </label>
                    <input type="text" class="form-control" id="token" name="token" value="<?php echo $bwpv_banlist['token']; ?>">
                  </div>
                
                  <div class="form-group col-md-6">
                    <label for="reason">Yasaklanma Sebebi
                    </label>
                    <textarea type="text" class="form-control" id="reason" rows="6" name="reason"><?php echo $bwpv_banlist['reason']; ?></textarea>
                  </div>
                  <input type='hidden' name='id' value='<?php echo $bwpv_banlist['id']; ?>' required>
                </div>

                <div class="form-group">
                    </div>

                <button type="submit" name="button_update_banned_player_information" class="btn btn-primary">Bilgileri Güncelle</button>
              </form>
            </div>
          </div>
        </li>
      </ul>
    </div>
</body>
</html>

<?php
if(isset($_POST['button_update_banned_player_information'])){

  $id = htmlspecialchars($_POST['id']);
  $steam = htmlspecialchars($_POST['steam']);
  $license = htmlspecialchars($_POST['license']);
  $xbl = htmlspecialchars($_POST['xbl']);
  $live = htmlspecialchars($_POST['live']);
  $discord = htmlspecialchars($_POST['discord']);
  $ip = htmlspecialchars($_POST['ip']);
  $token = htmlspecialchars($_POST['token']);
  $reason = htmlspecialchars($_POST['reason']);
	
  if(empty($steam)){
  	$steam = 'steam:';
  }
  if(empty($license)){
  	$steam = 'license:';
  }
  if(empty($xbl)){
  	$steam = 'xbl:';
  }
  if(empty($live)){
  	$live = 'live:';
  }
  if(empty($discord)){
  	$discord = 'discord:';
  }
  if(empty($ip)){
  	$ip = 'ip:';
  }
  if(empty($token)){
  	$token = 'token:';
  }

  if(empty($steam) OR empty($license) OR empty($xbl) OR empty($live) OR empty($discord) OR empty($ip) OR empty($reason)){
    die(SWEET_ALERT("error", "Erişim Engellendi", "Lütfen tüm alanları eksiksiz bir şekilde doldurun.", "Tamam", 0, 0, $FILE_NAME));
}

  if(empty($id)){
    echo SWEET_ALERT('error', 'Eksik Bilgi', 'Verinin ID`si alınamadı lütfen tekrar deneyin.', 'Tamam', "<center>Tarih : $CURRENT_DATE_AND_TIME<br>IP : $IP_ADDRESS</center>", "$FILE_NAME", "$FILE_NAME");
  }

LOG_USER_REQUEST($SESSION_USERNAME, "CVGRI Anti Cheat tarafından yasaklanmış bir oyuncunun verilerini düzenledi. [ steam:$steam, license:$license, xbl:$xbl, live:$live, discord:$discord, ip:$ip, token:$token, reason:$reason ]");

$update = $bwpv_pdo->prepare("UPDATE reality_banlist SET steam=?, license=?, xbl=?, discord=?, liveid=?, ip=?, token=?, reason=? WHERE id=?");
$update->execute([$steam, $license, $xbl, $discord, $live, $ip, $token, $reason, $id]);

if($update) {
  echo SWEET_ALERT('success', 'Başarılı', 'Kontroller sağlandı veri başarıyla güncellendi.', 'Tamam', "<center>Tarih : $CURRENT_DATE_AND_TIME<br>IP : $IP_ADDRESS</center>", "$FILE_NAME", "$FILE_NAME");
} else {
  echo SWEET_ALERT('error', 'Başarısız', 'Veriyi güncellemek için en az bir değer girmen lazım.', 'Tamam', "<center>Tarih : $CURRENT_DATE_AND_TIME<br>IP : $IP_ADDRESS</center>", "$FILE_NAME", "$FILE_NAME");
}

}

if($STATUS != true){
  ob_end_clean();
}

else{
  die();
}

?>
<!doctype html>
<html class="no-js h-100" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>
      <?php echo $PAGE_TITLE; ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php 

$CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $PERMISSION);

if($CHECK_PERMISSION == 0){
  include './assets/php/footer.php'; 
  die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_PERMISSION, "Tamam", 0, 0, $FILE_NAME));
}

?>
    <div class="main-content-container container-fluid px-4">

      <!-- PAGE HEADER -->
      <button type="button" class="btn mt-4 mb-4 text-white font-weight-bold" style="background-color: #FF6100">
        <?php echo $PAGE_TITLE; ?>
      </button>
      <!-- PAGE HEADER -->

<center><div class="p-3 mb-2 mt-4 bg-dark text-white font-weight-bold"><mark class="pr-5 pl-5 pb-1 font-weight-bold text-white">CVGRI Yasaklama Listesi</mark><br>
<button type="button" class="btn btn-success mt-3" style="width: 200px;" data-toggle="modal" data-target="#AddAccount">Oyuncu Yasaklama Menüsü</button>&nbsp;	
</div>
</center>
  <form method="POST" class="form-inline">
    <input class="form-control my-sm-2" name="search" id="search" type="search" placeholder="Steam Hex" value="steam:" aria-label="Steam Hex">
    <button class="btn btn-outline-success mx-2 my-sm-0" name="button_search" id="button_search" type="submit">Ara</button>
  </form>

<table class="table table-sm table-dark table-responsive">
  <thead>
    <tr>
      <?php
        echo '<th></th><th>ID</th><th>Steam Hex</th><th>Rockstar Lisansı</th><th>Xbox</th><th>Discord</th><th>Live ID</th><th>IP Adresi</th><th>FiveM Token</th><th>Yasaklanma Nedeni</th><th>Yasaklandığı Zaman</th><th>Yasağın Biteceği Zaman</th>';
      ?>
      <th width="200">&nbsp;</th>
    </tr>
  </thead>
  <tbody>
  <tr>

<?php

if(isset($_POST['button_search']) AND !empty($_POST['search'])){

    $search = $_POST['search'];
    $SQL = "SELECT * FROM reality_banlist WHERE `steam` LIKE :search;";
    $query = $bwpv_pdo->prepare($SQL);
    $query->bindValue(':search','%'.$search.'%');
    $query->execute();
    $query = $query->fetchAll(PDO::FETCH_ASSOC);

    $PAGINATION = 0;
  
} else {

  $COUNT_OF_SELECTED_QUERY = $bwpv_pdo->query("SELECT * FROM reality_banlist", PDO::FETCH_ASSOC);
  if($COUNT_OF_SELECTED_QUERY){
    $COUNT_OF_SELECTED_QUERY = $COUNT_OF_SELECTED_QUERY->rowCount();
  }
  else{
    echo "<br><h2><font color='red'>Bu veri tabanına erişilemiyor.</h2></font><br>";
  }
  if($COUNT_OF_SELECTED_QUERY == 0){
    echo "<br><h2><font color='red'>Bu veri tabanında bir veri bulunamadı.</h2></font><br>";
  }
  $PAGINATION = ceil($COUNT_OF_SELECTED_QUERY/10);
  if(!empty($_GET['PAGE'])){
    $PAGE = $_GET['PAGE'];
  }
  if(empty($PAGE)){
    $START_COUNT = 0;
    $FINAL_COUNT = 10;
  }
  else{
    $START_COUNT = ($PAGE-1)*10;
    $FINAL_COUNT = $START_COUNT+10;
  }

  $query = $bwpv_pdo->query("SELECT * FROM reality_banlist ORDER BY ID DESC LIMIT $START_COUNT, $FINAL_COUNT")->fetchAll(PDO::FETCH_ASSOC);

}

foreach ($query as $data):
$discord_id = str_replace('discord:', '', $data['discord']);
$ip_address = str_replace('ip:', '', $data['ip']);

echo '<td><button data-id="'.$data['id'].'"type="button" class="showeditmodal mb-2 btn btn-sm btn-success mr-1">Düzenle</button><br>
<button data-id="'.$data['id'].'"type="button" class="DELETE_BWPV mb-2 btn btn-sm mr-1 text-white btn-danger">Yasağı Kaldır</button></td>';

echo 
'<td>'.$data['id'].'<span onclick="copyOnclick(`'.$data['id'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.$data['steam'].'<span onclick="copyOnclick(`'.$data['steam'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.$data['license'].'<span onclick="copyOnclick(`'.$data['license'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.$data['xbl'].'<span onclick="copyOnclick(`'.$data['xbl'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.$data['discord'].'<span onclick="copyOnclick(`'.$data['discord'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span><span onclick="CHECK_DISCORD('.$discord_id.')"><i class="material-icons text-primary">wifi_find</i></span></td>
<td>'.$data['liveid'].'<span onclick="copyOnclick(`'.$data['liveid'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.$data['ip'].'<span onclick="copyOnclick(`'.$ip_address.'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span><span onclick="CHECK_IP_ADDRESS(`'.$ip_address.'`)"><i class="material-icons text-primary">wifi_find</i></span></td>
<td>'.$data['token'].'<span onclick="copyOnclick(`'.$data['token'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.$data['reason'].'<span onclick="copyOnclick(`'.$data['reason'].'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.EPOCH_CONVERTER($data['banned_date']).'<span onclick="copyOnclick(`'.EPOCH_CONVERTER($data['banned_date']).'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>
<td>'.EPOCH_CONVERTER($data['finish_date']).'<span onclick="copyOnclick(`'.EPOCH_CONVERTER($data['finish_date']).'`)">&nbsp;<i class="material-icons text-primary">content_copy</i></span></td>';
?>

  </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<nav aria-label="Page navigation example" class="mt-4">
    <ul class="pagination justify-content-left">
    <a class="page-link" href="<?php 
      if(empty($_GET['PAGE']) OR $_GET['PAGE'] == 1){
        $PREVIOUS_PAGE = 1;
        $NEXT_PAGE = 2;
      }
      else{
        $PREVIOUS_PAGE = $_GET['PAGE']-1;
        $NEXT_PAGE = $_GET['PAGE']+1;
      }
      echo "$FILE_NAME?PAGE=$PREVIOUS_PAGE";?>">Önceki</a></li>
    
    <?php for ($count = 1; $count <= $PAGINATION; $count++): ?>
      <?php 
        if($_GET['PAGE'] == $count){
          $ACTIVE_STATUS = "active"; 
        }
        else{
          $ACTIVE_STATUS = ""; 
        }
      ?>
       <li class="page-item <?= $ACTIVE_STATUS ?>">
            <a class="page-link" href="<?=$FILE_NAME.'?PAGE='.$count?>"><?=$count?></a>
        </li>
    <?php endfor; ?>
    
      <?php
      if($PAGINATION != $_GET['PAGE']){
        echo "<li class='page-item'><a class='page-link' href='$FILE_NAME?PAGE=$NEXT_PAGE'>Sonraki</a></li>";
      }
      ?>
    </ul>
</nav>

</div>
<br>
<!-- Footer Start -->
<?php include './assets/php/footer.php'; ?>
<!-- Footer End -->
</body>
</html>
<div class="modal fade bd-example-modal-lg" id="AddAccount" tabindex="-1" role="dialog" aria-labelledby="AddAccount" aria-hidden="true">
<div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Oyuncu Yasaklama Menüsü</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <li class="list-group-item p-3">
          <div class="row">
            <div class="col">
              <form method="POST">
                <div class="form-row">

                  <div class="form-group col-md-6">
                    <label for="steam">Steam Hex
                    </label>
                    <input type="text" class="form-control" id="steam" name="steam" value="steam:" required>
                  </div>

                  <div class="form-group col-md-6">
                    <label for="rockstar">Rockstart Lisansı
                    </label>
                    <input type="text" class="form-control" id="rockstar" name="rockstar" value="license:" required>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="xbox">Xbox Lisansı
                    </label>
                    <input type="text" class="form-control" id="xbox" name="xbox" value="xbl:" required>
                  </div>

                <div class="form-group col-md-6">
                    <label for="live">Live Lisansı
                    </label>
                    <input type="text" class="form-control" id="live" name="live" value="live:" required>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="discord">Discord
                    </label>
                    <input type="text" class="form-control" id="discord" name="discord" value="discord:" required>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="ip">IP Adresi
                    </label>
                    <input type="text" class="form-control" id="ip" name="ip" value="ip:" required>
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="reason">Yasaklanma Nedeni
                    </label>
                    <input type="text" class="form-control" id="reason" name="reason" required>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="ip">Yasaklama Süresi
                    </label>
                    <select id="inputState" name="time" id="time" class="form-control">
                        <option value="252460800" class="text-danger" selected>Kalıcı Yasaklama</option>
                        <option value="3600" class="text-primary">1 Saat</option>
                        <option value="7200" class="text-primary">2 Saat</option>
                        <option value="10800" class="text-primary">3 Saat</option>
                        <option value="86400" class="text-primary">1 Gün</option>
                        <option value="172800" class="text-primary">2 Gün</option>
                        <option value="259200" class="text-primary">3 Gün</option>
                        <option value="604800" class="text-primary">1 Hafta</option>
                        <option value="1209600" class="text-primary">2 Hafta</option>
                        <option value="2629800" class="text-primary">1 Ay</option>
                    </select> 
                  </div>
                  
                
                <div class="form-group">
                    </div>
                    </div>

                <button type="submit" name="button_ban_player" class="btn btn-danger">Oyuncuyu Yasakla</button>
                </form>
            </li>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kapat</button>
      </div>
    </div>
  </div>
</div>

<?php

if(isset($_POST['button_ban_player'])){

  $name = $UNIX_DATE;
  $admin = $SESSION_USERNAME;
  $steam = htmlspecialchars($_POST['steam']);
  $rockstar = htmlspecialchars($_POST['rockstar']);
  $xbox = htmlspecialchars($_POST['xbox']);
  $live = htmlspecialchars($_POST['live']);
  $discord = htmlspecialchars($_POST['discord']);
  $ip = htmlspecialchars($_POST['ip']);
  $reason = htmlspecialchars($_POST['reason']);
  $time = htmlspecialchars($_POST['time']);
  $time = $UNIX_DATE + $time;

  if(empty($steam) OR empty($rockstar) OR empty($xbox) OR empty($live) OR empty($discord) OR empty($ip) OR empty($reason)){
    die(SWEET_ALERT("error", "Erişim Engellendi", "Lütfen tüm alanları eksiksiz bir şekilde doldurun.", "Tamam", 0, 0, $FILE_NAME));
  }

  $query_reality_banlist = $bwpv_pdo->prepare("INSERT INTO reality_banlist SET name = ?, admin = ?, steam = ?, rockstar = ?, xbox = ?, live = ?, discord = ?, ip = ?, reason = ?, time = ?"); 
  $insert_reality_banlist = $query_reality_banlist->execute(array($name, $admin, $steam, $rockstar, $xbox, $live, $discord, $ip, $reason, $time));
  $LOG_USER_REQUEST = LOG_USER_REQUEST($SESSION_USERNAME, "Bir oyuncuyu sunucudan yasakladı. [ steam:$steam, rockstar:$rockstar, xbox:$xbox, live:$live, discord:$discord, ip:$ip, reason:$reason ]");
  
  if($insert_reality_banlist){
     echo SWEET_ALERT("success", "Başarılı", "Oyuncu başarıyla yasaklandı. Sunucuya girişi tamamen engellendi. Oyuncu eğer halen sunucudaysa sunucudan atmayı unutma.", "Tamam", 0, 0, $FILE_NAME);
     die();
  }
  else{
      echo SWEET_ALERT("error", "Başarısız", "Oyuncu yasaklanırken sistemsel bir problem oluştu, lütfen tekrar deneyin veya yazılım ekibi ile iletişime geçin.", "Tamam", 0, 0, $FILE_NAME);
      die();
  }

}
?>

<script>
function CHECK_IP_ADDRESS(IP_ADDRESS){
  href = "https://ip-api.com/#" + IP_ADDRESS;
  window.open(href, '_blank');
}

function CHECK_DISCORD(DISCORD_ID){
  href = "https://lookup.guru/" + DISCORD_ID;
  window.open(href, '_blank');
}
</script>
<script>
$('.showeditmodal').on('click', function(){
  const id = $(this).data('id')
  const csrf_token = '<?php echo GENERATE_CSRF_TOKEN(); ?>'
  window.location = "<?php echo $FILE_NAME; ?>?ACTION=EDIT&ID=" + id + "&CSRF_TOKEN=" + csrf_token;
});

function copyToClipboard(TEXT){
    var dummy = document.createElement("textarea");
    document.body.appendChild(dummy);
    dummy.value = TEXT;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
}

function copyOnclick(text){
  copyToClipboard(text);
  
  const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  background: '#191815', 
  color: '#fff',
  timer: 1200,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})

Toast.fire({
  icon: 'success',
  title: 'Kopyalandı'
})
}

$('.DELETE_BWPV').on('click', function(){
  const ID = $(this).data('id')
  const data = {
    ID: ID,
    DATABASE : 'reality_banlist',
    ACTION: 'DELETE_BWPV',
    CSRF_TOKEN: '<?php echo GENERATE_CSRF_TOKEN(); ?>',
    SESSION_USERNAME : '<?php echo $SESSION_USERNAME; ?>',
    SESSION_PERMISSION : '<?php echo $SESSION_PERMISSION; ?>'
  }
  $.post('./assets/php/ajax.php', data, function(response) {
    if(response.error){
      Swal.fire({
        icon: 'error',
        title: 'Yasak Kaldırılamadı',
        background: '#191815', 
        color: '#fff',
        text: response.error,
        footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
      }).then(function() { window.location = '<?php echo $FILE_NAME; ?>'});
    }
    if(response.success){
      Swal.fire({
        icon: 'success',
        title: 'Yasak Kaldırıldı',
        background: '#191815', 
        color: '#fff',
        text: response.success,
        footer: '<center>Tarih : <?php echo $CURRENT_DATE_AND_TIME; ?><br>IP Adresi : <?php echo $IP_ADDRESS; ?></center>'
      }).then(function() { window.location = '<?php echo $FILE_NAME; ?>'});
    }
  }, 'json')
});
</script>