<?php

$PERMISSION = ['admin', 'master', 'moderator', 'support'];
$CURRENT_PAGE = 'vipcars';
$FILE_NAME = $CURRENT_PAGE.'.php';
$PAGE_TITLE = 'Vip Araçlar ve Kodları';

include './assets/php/connection.php';
include './assets/php/bwpv_database.php';
include './assets/php/function.php';
include './assets/php/header.php';

ob_start();

?>
<!doctype html>
<html class="no-js h-100" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>
      <?php echo $PAGE_TITLE; ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php 

$CHECK_PERMISSION = CHECK_PERMISSION($SESSION_PERMISSION, $PERMISSION);

if($CHECK_PERMISSION == 0){
  include './assets/php/footer.php'; 
  die(SWEET_ALERT("error", "Erişim Engellendi", $DIE_PERMISSION, "Tamam", 0, 0, 'bannedusers.php'));
}

?>
    <div class="main-content-container container-fluid px-4">

      <!-- PAGE HEADER -->
      <!-- PAGE HEADER -->

  <div class="col py-4">
                <div class="card card-small mb-4">
                  <div class="card-header border-bottom">
                    <h6 class="m-0">(Your Server Name) Roleplay</h6>
                  </div>
                  <div class="card-body p-0 pb-5">
                    <table class="table mb-0">
                      <thead class="bg-light">
                        <tr>
                          <th scope="col" class="border-0">Spawn Code</th>
                          <th scope="col" class="border-0">Name</th>
                          <th scope="col" class="border-0">Price</th>
                          <th scope="col" class="border-0">Category</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                        $query = $bwpv_pdo->query("SELECT * FROM vip_vehicles ORDER BY category DESC")->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($query as $data):
                          echo '<tr>
                          <td>'.$data['model'].'</td>
                          <td>'.$data['name'].'</td>
                          <td>'.$data['price'].'</td>
                          <td>'.$data['category'].'</td>
                          </tr>';
                        endforeach;
                      ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              </div>
<?php

$query = $bwpv_pdo->query("SELECT * FROM items")->fetchAll(PDO::FETCH_ASSOC);

?>

<!-- Footer Start -->
<?php include './assets/php/footer.php'; ?>
<!-- Footer End -->